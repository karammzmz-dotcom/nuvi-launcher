package com.nuvi.launcher

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Garmin vehicle (.srf) support.
 * File layout (little endian): "GARMIN BITMAP 01", header, then N image sections. Each section is a strip of
 * square frames (36 frames, 10 degrees apart): 8-bit inverted alpha plane + 16-bit RGB (5-5-5 at bits 11/6/0).
 * Section 0 = 3D oblique view, section 1 = overhead view.
 */
object Vehicle {
    var frames: List<List<Bitmap>> = emptyList()

    val scale: Float get() = when (Prefs.vehicleScale) { 0 -> 0.7f; 2 -> 1.5f; else -> 1f }

    fun has() = frames.isNotEmpty()

    fun load(ctx: Context) {
        val f = File(ctx.filesDir, "vehicle.srf")
        frames = if (f.exists()) {
            try { parse(f.readBytes()) } catch (e: Exception) { emptyList() }
        } else emptyList()
    }

    fun reset(ctx: Context) {
        File(ctx.filesDir, "vehicle.srf").delete()
        frames = emptyList()
        Prefs.vehicleName = ""
    }

    /** returns an error message, or null on success */
    fun import(ctx: Context, uri: Uri): String? {
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return "Could not read file"
            val fr = parse(bytes)
            File(ctx.filesDir, "vehicle.srf").writeBytes(bytes)
            frames = fr
            Prefs.vehicleName = displayName(ctx, uri) ?: "Custom vehicle"
            null
        } catch (e: Exception) {
            "Not a valid Garmin .srf vehicle file"
        }
    }

    private fun displayName(ctx: Context, uri: Uri): String? =
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i) else null
            } else null
        }

    /** frame for a heading measured clockwise from screen-up, in degrees */
    fun frame(angle: Float): Bitmap? {
        if (frames.isEmpty()) return null
        val sec = frames[minOf(Prefs.vehicleView, frames.size - 1)]
        if (sec.isEmpty()) return null
        val n = sec.size
        var a = angle % 360f
        if (a < 0) a += 360f
        var i = Math.round(a / (360f / n)) % n
        if (!Prefs.vehicleCw) i = (n - i) % n
        return sec[i]
    }

    private fun skip(bb: ByteBuffer, n: Int) {
        if (n < 0 || n > bb.remaining()) throw IOException("corrupt file")
        bb.position(bb.position() + n)
    }

    /** Builds the rotation frames of one image section from its alpha and 16-bit colour planes. */
    private fun decode(data: ByteArray, alphaOff: Int, rgbOff: Int, w: Int, h: Int): List<Bitmap> {
        val px = IntArray(w * h)
        for (i in 0 until w * h) {
            val v = ((data[rgbOff + i * 2 + 1].toInt() and 0xFF) shl 8) or (data[rgbOff + i * 2].toInt() and 0xFF)
            val r = ((v shr 11) and 31) shl 3
            val g = ((v shr 6) and 31) shl 3
            val b = (v and 31) shl 3
            var a = (data[alphaOff + i].toInt() and 255) shl 1
            if (a >= 254) a = 255
            a = 255 - a
            px[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
        }
        val bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val n = maxOf(1, w / h)
        val list = ArrayList<Bitmap>()
        for (i in 0 until n) {
            val x = i * h
            val fw = minOf(h, w - x)
            if (fw <= 0) break
            list.add(Bitmap.createBitmap(bmp, x, 0, fw, h))
        }
        return list
    }

    fun parse(data: ByteArray): List<List<Bitmap>> {
        val id = String(data, 0, minOf(16, data.size))
        if (id != "GARMIN BITMAP 01") throw IOException("not an srf file")
        val std = try { parseHeader(data) } catch (e: Exception) { emptyList() }
        if (std.isNotEmpty()) return std
        val scan = parseScan(data)
        if (scan.isEmpty()) throw IOException("no images found")
        return scan
    }

    private fun parseHeader(data: ByteArray): List<List<Bitmap>> {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        skip(bb, 16 + 8)
        val count = bb.int
        skip(bb, 4 + 7 + 4)
        skip(bb, bb.int)          // version string
        skip(bb, 4)
        skip(bb, bb.int)          // product string
        if (count < 1 || count > 9) throw IOException("bad section count")
        val out = ArrayList<List<Bitmap>>()
        for (s in 0 until count) {
            skip(bb, 12)
            val h = bb.short.toInt() and 0xFFFF
            val w = bb.short.toInt() and 0xFFFF
            skip(bb, 2 + 2 + 4)
            skip(bb, 8)
            if (w <= 0 || h <= 0 || w * h > 4_000_000) throw IOException("bad size")
            val alphaOff = bb.position()
            skip(bb, w * h)
            skip(bb, 8)
            val rgbOff = bb.position()
            skip(bb, w * h * 2)
            out.add(decode(data, alphaOff, rgbOff, w, h))
        }
        return out
    }

    /** Fallback: look for image sections by their length fields instead of trusting the header. */
    private fun parseScan(data: ByteArray): List<List<Bitmap>> {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val out = ArrayList<List<Bitmap>>()
        var o = 16
        while (o + 40 < data.size) {
            val h = bb.getShort(o + 12).toInt() and 0xFFFF
            val w = bb.getShort(o + 14).toInt() and 0xFFFF
            if (w in 1..8192 && h in 1..2048 && w * h <= 4_000_000) {
                val lenPos = o + 28
                if (lenPos + 4 <= data.size && bb.getInt(lenPos) == w * h) {
                    val aOff = lenPos + 4
                    val rgbLenPos = aOff + w * h + 4
                    if (rgbLenPos + 4 + w * h * 2 <= data.size && bb.getInt(rgbLenPos) == w * h * 2) {
                        out.add(decode(data, aOff, rgbLenPos + 4, w, h))
                        o = rgbLenPos + 4 + w * h * 2
                        continue
                    }
                }
            }
            o++
        }
        return out
    }
}
