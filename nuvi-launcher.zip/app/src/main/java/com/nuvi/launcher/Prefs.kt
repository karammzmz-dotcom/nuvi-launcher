package com.nuvi.launcher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class Place(val name: String, val addr: String, val lat: Double, val lon: Double) {
    fun toJson(): JSONObject = JSONObject().put("n", name).put("a", addr).put("la", lat).put("lo", lon)

    companion object {
        fun from(o: JSONObject) = Place(o.getString("n"), o.optString("a"), o.getDouble("la"), o.getDouble("lo"))
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("nuvi", Context.MODE_PRIVATE) }

    private fun gb(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun gi(k: String, d: Int) = sp.getInt(k, d)
    private fun sb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun si(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var miles: Boolean
        get() = gb("miles", false)
        set(v) = sb("miles", v)
    var h24: Boolean
        get() = gb("h24", false)
        set(v) = sb("h24", v)
    var immersive: Boolean
        get() = gb("immersive", true)
        set(v) = sb("immersive", v)
    var orientation: Int
        get() = gi("orientation", 0)
        set(v) = si("orientation", v)
    var brightness: Int
        get() = gi("brightness", 0)
        set(v) = si("brightness", v)
    var colorMode: Int
        get() = gi("colorMode", 0)
        set(v) = si("colorMode", v)
    var northUp: Boolean
        get() = gb("northUp", false)
        set(v) = sb("northUp", v)
    var avoidHw: Boolean
        get() = gb("avoidHw", false)
        set(v) = sb("avoidHw", v)
    var avoidToll: Boolean
        get() = gb("avoidToll", false)
        set(v) = sb("avoidToll", v)
    var voice: Boolean
        get() = gb("voice", true)
        set(v) = sb("voice", v)
    var voiceUk: Boolean
        get() = gb("voiceUk", false)
        set(v) = sb("voiceUk", v)
    var keyTones: Boolean
        get() = gb("keyTones", true)
        set(v) = sb("keyTones", v)
    var kbArabic: Boolean
        get() = gb("kbArabic", false)
        set(v) = sb("kbArabic", v)

    fun getS(k: String, d: String): String = sp.getString(k, d) ?: d
    fun putS(k: String, v: String) { sp.edit().putString(k, v).apply() }

    var vehicleName: String
        get() = getS("vehName", "")
        set(v) = putS("vehName", v)
    var vehicleView: Int
        get() = gi("vehView", 1)
        set(v) = si("vehView", v)
    var vehicleCw: Boolean
        get() = gb("vehCw", true)
        set(v) = sb("vehCw", v)
    var vehicleScale: Int
        get() = gi("vehScale", 1)
        set(v) = si("vehScale", v)
    var fuelType: Int
        get() = gi("fuelType", 0)
        set(v) = si("fuelType", v)
    var ecoL100: Float
        get() = sp.getFloat("ecoL100", 8f)
        set(v) { sp.edit().putFloat("ecoL100", v).apply() }
    var fuelPrice: Float
        get() = sp.getFloat("fuelPrice", 1f)
        set(v) { sp.edit().putFloat("fuelPrice", v).apply() }

    var autoZoom: Boolean
        get() = gb("autoZoom", true)
        set(v) = sb("autoZoom", v)
    var speedAlert: Boolean
        get() = gb("speedAlert", true)
        set(v) = sb("speedAlert", v)
    var routeShorter: Boolean
        get() = gb("routeShorter", false)
        set(v) = sb("routeShorter", v)
    var sim: Boolean
        get() = gb("sim", false)
        set(v) = sb("sim", v)

    fun restoreSettings() {
        val e = sp.edit()
        for (k in listOf("miles", "h24", "immersive", "orientation", "brightness", "colorMode", "northUp", "avoidHw", "avoidToll",
            "voice", "voiceUk", "keyTones", "kbArabic", "vehView", "vehCw", "vehScale", "autoZoom", "speedAlert", "routeShorter", "sim")) e.remove(k)
        e.apply()
    }

    var home: Place?
        get() = try { sp.getString("home", null)?.let { Place.from(JSONObject(it)) } } catch (e: Exception) { null }
        set(v) { sp.edit().putString("home", v?.toJson()?.toString()).apply() }

    fun places(k: String): MutableList<Place> {
        val out = ArrayList<Place>()
        try {
            val a = JSONArray(sp.getString(k, "[]"))
            for (i in 0 until a.length()) out.add(Place.from(a.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    private fun putPlaces(k: String, l: List<Place>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp.edit().putString(k, a.toString()).apply()
    }

    fun addRecent(p: Place) {
        val l = places("recent")
        l.removeAll { it.lat == p.lat && it.lon == p.lon }
        l.add(0, p)
        putPlaces("recent", l.take(50))
    }

    fun isSaved(p: Place) = places("saved").any { it.lat == p.lat && it.lon == p.lon }

    fun toggleSaved(p: Place): Boolean {
        val l = places("saved")
        val had = l.removeAll { it.lat == p.lat && it.lon == p.lon }
        if (!had) l.add(0, p)
        putPlaces("saved", l)
        return !had
    }

    fun queries(): List<String> {
        val out = ArrayList<String>()
        try {
            val a = JSONArray(sp.getString("queries", "[]"))
            for (i in 0 until a.length()) out.add(a.getString(i))
        } catch (e: Exception) { }
        return out
    }

    fun addQuery(q: String) {
        val l = queries().toMutableList()
        l.removeAll { it.equals(q, true) }
        l.add(0, q)
        val a = JSONArray()
        l.take(30).forEach { a.put(it) }
        sp.edit().putString("queries", a.toString()).apply()
    }
}
