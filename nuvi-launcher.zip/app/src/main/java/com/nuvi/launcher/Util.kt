package com.nuvi.launcher

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.speech.tts.TextToSpeech
import java.util.Calendar
import java.util.Locale
import kotlin.math.*

fun hav(la1: Double, lo1: Double, la2: Double, lo2: Double): Double {
    val r = 6371000.0
    val p1 = Math.toRadians(la1)
    val p2 = Math.toRadians(la2)
    val dp = p2 - p1
    val dl = Math.toRadians(lo2 - lo1)
    val x = sin(dp / 2).pow(2) + cos(p1) * cos(p2) * sin(dl / 2).pow(2)
    return 2 * r * asin(min(1.0, sqrt(x)))
}

object Fmt {
    fun distParts(m: Double): Pair<String, String> {
        if (Prefs.miles) {
            val mi = m / 1609.344
            if (mi < 0.1) return Pair(((m * 3.28084 / 50).roundToInt() * 50).toString(), "ft")
            return Pair(if (mi < 10) String.format(Locale.US, "%.1f", mi) else mi.roundToInt().toString(), "mi")
        }
        if (m < 1000) return Pair(((m / 10).roundToInt() * 10).toString(), "m")
        val km = m / 1000
        return Pair(if (km < 10) String.format(Locale.US, "%.1f", km) else km.roundToInt().toString(), "km")
    }

    fun dist(m: Double): String { val d = distParts(m); return d.first + " " + d.second }

    fun spoken(m: Double): String {
        if (Prefs.miles) {
            val mi = m / 1609.344
            return if (mi < 0.1) "${(m * 3.28084 / 50).roundToInt() * 50} feet"
            else String.format(Locale.US, "%.1f miles", mi)
        }
        return if (m < 1000) "${(m / 10).roundToInt() * 10} meters" else String.format(Locale.US, "%.1f kilometers", m / 1000)
    }

    /** value + two stacked unit letters, like "m/h" on the real device */
    fun speedParts(ms: Float): Pair<String, String> =
        if (Prefs.miles) Pair((ms * 2.23694f).roundToInt().toString(), "mh") else Pair((ms * 3.6f).roundToInt().toString(), "kh")

    fun clock(ms: Long): Pair<String, String> {
        val c = Calendar.getInstance()
        c.timeInMillis = ms
        val h = c.get(Calendar.HOUR_OF_DAY)
        val m = c.get(Calendar.MINUTE)
        return if (Prefs.h24) Pair(String.format(Locale.US, "%02d:%02d", h, m), "")
        else Pair(String.format(Locale.US, "%d:%02d", if (h % 12 == 0) 12 else h % 12, m), if (h < 12) "AM" else "PM")
    }

    fun duration(sec: Double): String {
        val m = (sec / 60).roundToInt()
        return if (m >= 60) "${m / 60} h ${m % 60} min" else "$m min"
    }

    fun coord(lat: Double, lon: Double) = String.format(Locale.US, "%.5f, %.5f", lat, lon)
}

object Cats {
    class Cat(val name: String, val icon: String, val filter: String)

    val all = listOf(
        Cat("Food", "food", """["amenity"~"^(fast_food|cafe|food_court|ice_cream)$"]"""),
        Cat("Fuel", "fuel", """["amenity"="fuel"]"""),
        Cat("Lodging", "lodging", """["tourism"~"^(hotel|motel|hostel|guest_house|apartment)$"]"""),
        Cat("Shopping", "shopping", """["shop"~"^(mall|supermarket|department_store|convenience|clothes)$"]"""),
        Cat("Parking", "parking", """["amenity"="parking"]"""),
        Cat("Hospitals", "hospital", """["amenity"~"^(hospital|clinic)$"]"""),
        Cat("ATMs", "atm", """["amenity"="atm"]"""),
        Cat("Restaurants", "restaurant", """["amenity"="restaurant"]"""),
        Cat("Attractions", "attraction", """["tourism"~"^(attraction|museum|viewpoint|zoo|theme_park|gallery)$"]""")
    )

    fun byName(n: String) = all.first { it.name == n }
}

object Voice {
    private var tts: TextToSpeech? = null
    private var ready = false

    fun init(ctx: Context) {
        tts = TextToSpeech(ctx.applicationContext) { ready = it == TextToSpeech.SUCCESS }
    }

    fun say(s: String) {
        val t = tts ?: return
        if (!ready || !Prefs.voice) return
        t.language = if (Prefs.voiceUk) Locale.UK else Locale.US
        t.speak(s, TextToSpeech.QUEUE_FLUSH, null, "nuvi")
    }
}

object Sound {
    private var tg: ToneGenerator? = null

    private fun gen(): ToneGenerator? {
        if (tg == null) {
            try { tg = ToneGenerator(AudioManager.STREAM_SYSTEM, 35) } catch (e: Exception) { }
        }
        return tg
    }

    fun click() { if (Prefs.keyTones) gen()?.startTone(ToneGenerator.TONE_PROP_BEEP, 40) }
    fun chime() { if (Prefs.keyTones) gen()?.startTone(ToneGenerator.TONE_PROP_ACK, 200) }
}
