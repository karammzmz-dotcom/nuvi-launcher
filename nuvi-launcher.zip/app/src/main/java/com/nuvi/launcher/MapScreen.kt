package com.nuvi.launcher

import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.location.Location
import android.os.SystemClock
import android.view.MotionEvent
import android.widget.FrameLayout
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline
import java.util.Calendar
import kotlin.math.hypot

/** Blue car/arrow marker for the current position. */
class CarOverlay : Overlay() {
    var gp: GeoPoint? = null
    var bearing = 0f
    private val pt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    override fun draw(c: Canvas, mv: MapView, shadow: Boolean) {
        if (shadow) return
        val g = gp ?: return
        val pp = mv.projection.toPixels(g, null)
        val x = pp.x.toFloat()
        val y = pp.y.toFloat()
        val s = DENSITY * 11f
        val fr = Vehicle.frame(bearing + mv.mapOrientation)
        if (fr != null) {
            val sz = DENSITY * 52f * Vehicle.scale
            c.save()
            c.rotate(-mv.mapOrientation, x, y)
            c.drawBitmap(fr, null, RectF(x - sz / 2, y - sz / 2, x + sz / 2, y + sz / 2), bp)
            c.restore()
            return
        }
        c.save()
        c.rotate(bearing, x, y)
        pt.reset(); pt.isAntiAlias = true; pt.color = 0x55000000
        c.drawRoundRect(RectF(x - s * .6f + 3f, y - s * 1.1f + 4f, x + s * .6f + 3f, y + s * 1.1f + 4f), s * .5f, s * .5f, pt)
        pt.reset(); pt.isAntiAlias = true
        pt.shader = LinearGradient(x - s, y, x + s, y, 0xFF5CB4FF.toInt(), 0xFF1B5FB0.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(x - s * .6f, y - s * 1.1f, x + s * .6f, y + s * 1.1f), s * .5f, s * .5f, pt)
        pt.reset(); pt.isAntiAlias = true; pt.style = Paint.Style.STROKE; pt.strokeWidth = 2f; pt.color = Color.WHITE
        c.drawRoundRect(RectF(x - s * .6f, y - s * 1.1f, x + s * .6f, y + s * 1.1f), s * .5f, s * .5f, pt)
        pt.reset(); pt.isAntiAlias = true; pt.color = 0xFFE8F4FF.toInt()
        c.drawRoundRect(RectF(x - s * .4f, y - s * .55f, x + s * .4f, y - s * .1f), s * .15f, s * .15f, pt)
        c.restore()
    }
}

class MapScreen(private val app: MainActivity) : FrameLayout(app), Screen {
    val map = MapView(app)
    private val hud = MapHud(app, this)
    var follow = true
    var speedMs = 0f
    var roadName = ""
    var limitKmh = 0
    private var bearing = 0f
    private var lastRoad = 0L
    private var roadBusy = false
    private var drawn: Route? = null
    private val car = CarOverlay()
    private val rOut = Polyline()
    private val rIn = Polyline()
    private var destMk: Marker? = null
    private var pinMk: Marker? = null
    private var centered = false
    /** osmdroid MapViews cannot be re-attached after being detached; MainActivity rebuilds a dead one. */
    var dead = false
    private var dx = 0f
    private var dy = 0f
    private val locL: (Location) -> Unit = { onLoc(it) }

    val night: Boolean
        get() = when (Prefs.colorMode) {
            1 -> false
            2 -> true
            else -> { val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); h >= 19 || h < 6 }
        }

    init {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.isTilesScaledToDpi = true
        map.minZoomLevel = 3.0
        map.maxZoomLevel = 19.0
        val l0 = Gps.loc
        if (l0 != null) {
            map.controller.setZoom(16.0)
            map.controller.setCenter(GeoPoint(l0.latitude, l0.longitude))
            centered = true
        } else {
            map.controller.setZoom(3.0)
            map.controller.setCenter(GeoPoint(25.0, 20.0))
        }

        rOut.outlinePaint.color = 0xFF7A1A5C.toInt()
        rOut.outlinePaint.strokeWidth = DENSITY * 11f
        rOut.outlinePaint.strokeCap = Paint.Cap.ROUND
        rOut.outlinePaint.strokeJoin = Paint.Join.ROUND
        rIn.outlinePaint.color = 0xFFD94BA6.toInt()
        rIn.outlinePaint.strokeWidth = DENSITY * 7f
        rIn.outlinePaint.strokeCap = Paint.Cap.ROUND
        rIn.outlinePaint.strokeJoin = Paint.Join.ROUND

        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint?): Boolean = false
            override fun longPressHelper(p: GeoPoint?): Boolean {
                if (p == null) return false
                app.showPlace(Place("Dropped Pin", Fmt.coord(p.latitude, p.longitude), p.latitude, p.longitude))
                return true
            }
        }))
        map.overlays.add(car)
        map.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.x; dy = e.y }
                MotionEvent.ACTION_MOVE ->
                    if (follow && e.pointerCount == 1 && hypot(e.x - dx, e.y - dy) > 30 * DENSITY) { follow = false; hud.invalidate() }
            }
            false
        }
        addView(map, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(hud, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        dead = true
    }

    override fun onShow() {
        map.onResume()
        Gps.listeners.add(locL)
        Nav.onChange = { post { refreshRoute(); hud.invalidate() } }
        applyTheme()
        refreshRoute()
        Gps.loc?.let { onLoc(it) }
        app.keepOn(true)
    }

    override fun onHide() {
        map.onPause()
        Gps.listeners.remove(locL)
        Nav.onChange = null
        app.keepOn(false)
    }

    private fun applyTheme() {
        val cm = if (night) {
            val inv = ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f))
            inv.postConcat(ColorMatrix(floatArrayOf(-0.574f, 1.43f, 0.144f, 0f, 0f, 0.426f, 0.43f, 0.144f, 0f, 0f, 0.426f, 1.43f, -0.856f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
            inv.postConcat(ColorMatrix(floatArrayOf(0.8f, 0f, 0f, 0f, 0f, 0f, 0.8f, 0f, 0f, 0f, 0f, 0f, 0.8f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
            inv
        } else {
            val s = ColorMatrix()
            s.setSaturation(0.75f)
            s
        }
        map.overlayManager.tilesOverlay.setColorFilter(ColorMatrixColorFilter(cm))
        map.invalidate()
        hud.invalidate()
    }

    fun refreshRoute() {
        val r = Nav.route
        if (r === drawn) return
        drawn = r
        map.overlays.remove(rOut)
        map.overlays.remove(rIn)
        destMk?.let { map.overlays.remove(it) }
        destMk = null
        if (r != null) {
            val pts = ArrayList<GeoPoint>(r.lat.size)
            for (i in r.lat.indices) pts.add(GeoPoint(r.lat[i], r.lon[i]))
            rOut.setPoints(pts)
            rIn.setPoints(pts)
            map.overlays.add(rOut)
            map.overlays.add(rIn)
            val d = Nav.dest
            if (d != null) destMk = marker(Place(d.name, d.addr, d.lat, d.lon))
        }
        map.overlays.remove(car)
        map.overlays.add(car)
        map.invalidate()
    }

    private fun marker(p: Place): Marker {
        val m = Marker(map)
        m.position = GeoPoint(p.lat, p.lon)
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        m.icon = BitmapDrawable(resources, Icons.bitmap("mapPin", (DENSITY * 36).toInt()))
        m.setOnMarkerClickListener { _, _ -> app.showPlace(p); true }
        map.overlays.add(m)
        return m
    }

    fun showPin(p: Place) {
        pinMk?.let { map.overlays.remove(it) }
        pinMk = marker(p)
        follow = false
        centered = true
        map.mapOrientation = 0f
        map.controller.setZoom(16.0)
        map.controller.setCenter(GeoPoint(p.lat, p.lon))
        map.overlays.remove(car)
        map.overlays.add(car)
        map.invalidate()
        hud.invalidate()
    }

    fun recenter() {
        follow = true
        Gps.loc?.let { onLoc(it) }
        hud.invalidate()
    }

    fun zoom(d: Int) {
        if (d > 0) map.controller.zoomIn() else map.controller.zoomOut()
    }

    private fun onLoc(l: Location) {
        val g = GeoPoint(l.latitude, l.longitude)
        car.gp = g
        if (!centered && follow) { centered = true; map.controller.setZoom(16.0) }
        if (l.hasBearing() && l.speed > 1.5f) bearing = l.bearing
        car.bearing = bearing
        speedMs = if (l.hasSpeed()) l.speed else 0f
        if (follow) {
            map.controller.setCenter(g)
            map.mapOrientation = if (Prefs.northUp) 0f else -bearing
        }
        maybeRoad(l)
        map.invalidate()
        hud.invalidate()
    }

    private fun maybeRoad(l: Location) {
        val now = SystemClock.elapsedRealtime()
        if (roadBusy || now - lastRoad < 15000) return
        roadBusy = true
        lastRoad = now
        Net.async({ Net.roadInfo(l.latitude, l.longitude) }) { r ->
            roadBusy = false
            r.onSuccess { roadName = it.first; limitKmh = it.second; Eco.limitKmh = it.second; hud.invalidate() }
        }
    }
}

/** Garmin-style overlay: turn panel, street sign, speed / arrival panels, zoom, limit sign. */
class MapHud(private val app: MainActivity, private val ms: MapScreen) : Pane(app) {
    private var mode = 0
    init { tickMs = 2000 }

    override fun draw0(c: Canvas) {
        val night = ms.night
        val pt = if (night) 0xFF3A4046.toInt() else 0xFFF3F3F3.toInt()
        val pb = if (night) 0xFF22262A.toInt() else 0xFFC8CCD0.toInt()
        val ink = if (night) 0xFFEEEEEE.toInt() else 0xFF1A1A1A.toInt()
        val edge = if (night) 0xFF0E0E0E.toInt() else 0xFF7C8084.toInt()
        val dark1 = 0xFF3F5063.toInt()
        val dark2 = 0xFF26323E.toInt()
        val by = H - 44f
        val route = Nav.route

        // ---- bottom bar
        box(c, 140f, by + 14f, W - 140f, H, pt, pb, edge)
        val road = if (ms.roadName.isNotBlank()) ms.roadName else if (Gps.hasFix()) "" else "Acquiring satellites…"
        text(c, fit(road, 15f, W - 310f, true), W / 2, H - 9f, 15f, ink, true, Paint.Align.CENTER)

        val sp = Path()
        sp.moveTo(52f, by); sp.lineTo(138f, by); sp.lineTo(152f, H); sp.lineTo(52f, H); sp.close()
        poly(c, sp, pt, pb, by, H, edge)
        text(c, "Speed", 92f, by + 13f, 11f, ink, false, Paint.Align.CENTER)
        val spd = Fmt.speedParts(ms.speedMs)
        valueUnit(c, spd.first, spd.second, 96f, H - 6f, 26f, ink)

        val ap = Path()
        ap.moveTo(W - 138f, by); ap.lineTo(W - 52f, by); ap.lineTo(W - 52f, H); ap.lineTo(W - 152f, H); ap.close()
        poly(c, ap, pt, pb, by, H, edge)
        val ax = W - 96f
        hit(W - 152f, by, W - 52f, H) { mode = (mode + 1) % 3; invalidate() }
        if (route == null) {
            text(c, "Time", ax, by + 13f, 11f, ink, false, Paint.Align.CENTER)
            val t = Fmt.clock(System.currentTimeMillis())
            valueUnit(c, t.first, t.second.take(2), ax, H - 6f, 24f, ink)
        } else when (mode) {
            0 -> {
                text(c, "Arrival", ax, by + 13f, 11f, ink, false, Paint.Align.CENTER)
                val t = Fmt.clock(Nav.eta)
                valueUnit(c, t.first, t.second, ax, H - 6f, 24f, ink)
            }
            1 -> {
                text(c, "Remaining", ax, by + 13f, 11f, ink, false, Paint.Align.CENTER)
                val d = Fmt.distParts(Nav.remaining)
                valueUnit(c, d.first, d.second, ax, H - 6f, 24f, ink)
            }
            else -> {
                text(c, "Time left", ax, by + 13f, 11f, ink, false, Paint.Align.CENTER)
                text(c, Fmt.duration(Nav.remDur), ax, H - 8f, 17f, ink, true, Paint.Align.CENTER)
            }
        }

        val b = hit(0f, by, 52f, H) { app.goHome() }
        box(c, 0f, by, 52f, H, if (b) 0xFF5A7088.toInt() else dark1, dark2, 0xFF0E1822.toInt())
        Icons.draw(c, "back", 26f, by + 22f, 28f, Color.WHITE)
        val m = hit(W - 52f, by, W, H) { app.openMapMenu() }
        box(c, W - 52f, by, W, H, if (m) 0xFF5A7088.toInt() else dark1, dark2, 0xFF0E1822.toInt())
        Icons.draw(c, "menu", W - 26f, by + 22f, 26f, Color.WHITE)

        // ---- top bar (only while navigating)
        var zy = 20f
        if (route != null) {
            zy = 54f
            val st = route.steps[minOf(Nav.stepIdx, route.steps.size - 1)]
            hit(0f, 0f, W, 44f) { app.openTurnList() }
            val tp = Path()
            tp.moveTo(0f, 0f); tp.lineTo(94f, 0f); tp.lineTo(100f, 44f); tp.lineTo(0f, 44f); tp.close()
            poly(c, tp, pt, pb, 0f, 44f, edge)
            drawTurn(c, 24f, 22f, 30f, st, ink)
            val d = Fmt.distParts(Nav.distToTurn)
            valueUnit(c, d.first, d.second, 66f, 31f, 22f, ink)
            val green = st.dest.isNotBlank() || st.exit.isNotBlank()
            val label = if (st.dest.isNotBlank()) st.dest.replace(",", " / ") else st.road
            if (green) {
                fill(c, 100f, 0f, W, 44f, 0xFF0E6B3C.toInt())
                fill(c, 100f, 43f, W, 44f, 0xFF0A4A2A.toInt())
                var tx = 110f
                if (st.exit.isNotBlank()) {
                    fill(c, 100f, 0f, 150f, 44f, 0xFF0A5430.toInt())
                    text(c, "Exit", 125f, 15f, 10f, Color.WHITE, false, Paint.Align.CENTER)
                    text(c, fit(st.exit, 17f, 46f, true), 125f, 36f, 17f, Color.WHITE, true, Paint.Align.CENTER)
                    tx = 160f
                }
                text(c, fit(label, 22f, W - tx - 8f), tx, 31f, 22f, Color.WHITE)
            } else {
                box(c, 100f, 0f, W, 44f, pt, pb, edge)
                text(c, fit(if (label.isBlank()) st.text else label, 22f, W - 116f), 112f, 31f, 22f, ink)
            }
        }
        if (Nav.calculating) {
            fill(c, W / 2 - 80f, 56f, W / 2 + 80f, 84f, 0xE6202020.toInt())
            text(c, "Calculating…", W / 2, 76f, 16f, Color.WHITE, false, Paint.Align.CENTER)
        }

        // ---- status banner (explains a blank map)
        val warn = if (!app.online()) "No internet - map tiles can't load" else if (Gps.loc == null) "Acquiring GPS position…" else null
        if (warn != null && !Nav.calculating) {
            val ty = if (route != null) 52f else 8f
            fill(c, 46f, ty, W - 6f, ty + 24f, 0xE6202020.toInt())
            text(c, fit(warn, 13f, W - 70f), (46f + W - 6f) / 2, ty + 17f, 13f, Color.WHITE, false, Paint.Align.CENTER)
        }

        // ---- zoom controls
        p.reset(); p.isAntiAlias = true; p.color = if (night) 0xAA2A2E32.toInt() else 0xAAF2F2F2.toInt()
        c.drawRoundRect(RectF(4f, zy, 38f, zy + 80f), 3f, 3f, p)
        hit(4f, zy, 38f, zy + 40f) { ms.zoom(1) }
        hit(4f, zy + 40f, 38f, zy + 80f) { ms.zoom(-1) }
        Icons.draw(c, "plus", 21f, zy + 20f, 24f, if (night) Color.WHITE else 0xFF3A3A3A.toInt())
        Icons.draw(c, "minus", 21f, zy + 60f, 24f, if (night) Color.WHITE else 0xFF3A3A3A.toInt())

        // ---- speed limit
        if (ms.limitKmh > 0) {
            val lim = if (Prefs.miles) (Math.round(ms.limitKmh / 1.609f / 5f) * 5) else ms.limitKmh
            box(c, 6f, by - 46f, 36f, by - 8f, Color.WHITE, Color.WHITE, Color.BLACK, 3f)
            text(c, "LIMIT", 21f, by - 34f, 7.5f, Color.BLACK, true, Paint.Align.CENTER)
            text(c, lim.toString(), 21f, by - 14f, 18f, Color.BLACK, true, Paint.Align.CENTER)
        }

        // ---- re-center
        if (!ms.follow) {
            val r = hit(W / 2 - 50f, by - 36f, W / 2 + 50f, by - 8f) { ms.recenter() }
            box(c, W / 2 - 50f, by - 36f, W / 2 + 50f, by - 8f, if (r) 0xFF5A7088.toInt() else dark1, dark2, 0xFF0E1822.toInt(), 3f)
            text(c, "Re-center", W / 2, by - 17f, 14f, Color.WHITE, false, Paint.Align.CENTER)
        }

        // ---- OSM attribution (required by the OpenStreetMap licence)
        fill(c, W - 96f, by - 12f, W, by, 0xAAFFFFFF.toInt())
        text(c, "© OpenStreetMap", W - 3f, by - 3f, 8f, 0xFF333333.toInt(), false, Paint.Align.RIGHT)
    }

    private fun drawTurn(c: Canvas, cx: Float, cy: Float, s: Float, st: Step, col: Int) {
        c.save()
        c.translate(cx, cy)
        p.reset(); p.isAntiAlias = true; p.color = col
        p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.16f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        if (st.type == "arrive") {
            Icons.draw(c, "mapPin", 0f, 0f, s, col)
        } else if (st.mod == "uturn") {
            val a = Path()
            a.moveTo(s * .25f, s * .5f); a.lineTo(s * .25f, -s * .1f)
            a.quadTo(s * .25f, -s * .5f, 0f, -s * .5f); a.quadTo(-s * .25f, -s * .5f, -s * .25f, -s * .1f); a.lineTo(-s * .25f, s * .15f)
            c.drawPath(a, p)
            val h = Path()
            h.moveTo(-s * .5f, s * .1f); h.lineTo(0f, s * .1f); h.lineTo(-s * .25f, s * .5f); h.close()
            p.style = Paint.Style.FILL
            c.drawPath(h, p)
        } else {
            val ang = Math.toRadians(st.angle.toDouble())
            val ex = (Math.sin(ang) * s * .5).toFloat()
            val ey = (-Math.cos(ang) * s * .5).toFloat()
            val a = Path()
            a.moveTo(0f, s * .5f); a.lineTo(0f, 0f); a.lineTo(ex, ey)
            c.drawPath(a, p)
            // arrow head at (ex, ey) pointing along the angle
            c.save()
            c.translate(ex, ey)
            c.rotate(st.angle)
            val h = Path()
            h.moveTo(0f, -s * .22f); h.lineTo(-s * .2f, s * .08f); h.lineTo(s * .2f, s * .08f); h.close()
            p.style = Paint.Style.FILL
            c.drawPath(h, p)
            c.restore()
        }
        c.restore()
    }
}
