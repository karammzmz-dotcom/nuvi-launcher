package com.nuvi.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.MotionEvent
import org.json.JSONObject
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

// ====================================================================== Trip Computer
object TripComp {
    var odo = 0.0
    var dist = 0.0
    var moving = 0.0
    var stopped = 0.0
    var maxMs = 0f
    private var pt = 0L
    private var lastSave = 0L

    fun load() {
        try {
            val o = JSONObject(Prefs.getS("tc", "{}"))
            odo = o.optDouble("odo", 0.0); dist = o.optDouble("d", 0.0)
            moving = o.optDouble("m", 0.0); stopped = o.optDouble("s", 0.0)
            maxMs = o.optDouble("x", 0.0).toFloat()
        } catch (e: Exception) { }
    }

    private fun save() {
        Prefs.putS("tc", JSONObject().put("odo", odo).put("d", dist).put("m", moving).put("s", stopped).put("x", maxMs.toDouble()).toString())
    }

    fun update(l: Location) {
        val t = l.time
        if (pt > 0) {
            val dt = (t - pt) / 1000.0
            if (dt in 0.2..10.0) {
                val v = if (l.hasSpeed()) l.speed else 0f
                if (v > 0.7f) { moving += dt; dist += v * dt; odo += v * dt } else stopped += dt
                if (v > maxMs) maxMs = v
            }
        }
        pt = t
        val now = SystemClock.elapsedRealtime()
        if (now - lastSave > 15000) { lastSave = now; save() }
    }

    fun resetTrip() { dist = 0.0; moving = 0.0; stopped = 0.0; save() }
    fun resetMax() { maxMs = 0f; save() }
}

fun openTripComputer(app: MainActivity) {
    app.push(ListPane(app, "Trip Computer") {
        val total = TripComp.moving + TripComp.stopped
        listOf(
            Row("Odometer", value = Fmt.dist(TripComp.odo)),
            Row("Trip Distance", value = Fmt.dist(TripComp.dist)),
            Row("Moving Time", value = Fmt.duration(TripComp.moving)),
            Row("Stopped Time", value = Fmt.duration(TripComp.stopped)),
            Row("Moving Average", value = Fmt.speedStr(if (TripComp.moving > 0) (TripComp.dist / TripComp.moving).toFloat() else 0f)),
            Row("Overall Average", value = Fmt.speedStr(if (total > 0) (TripComp.dist / total).toFloat() else 0f)),
            Row("Total Time", value = Fmt.duration(total)),
            Row("Max Speed", value = Fmt.speedStr(TripComp.maxMs)),
            Row("Reset Trip Data", icon = "stop", tap = { TripComp.resetTrip(); app.toast("Trip data reset") }),
            Row("Reset Max Speed", icon = "stop", tap = { TripComp.resetMax(); app.toast("Max speed reset") })
        )
    })
}

// ====================================================================== Where Am I?
fun openWhereAmI(app: MainActivity) {
    var addr = "Locating address…"
    lateinit var lp: ListPane
    val here0 = Gps.loc
    if (here0 != null) {
        Net.async({ Net.reverse(here0.latitude, here0.longitude) }) { r ->
            val a = r.getOrNull()
            addr = if (a.isNullOrBlank()) "Address not available" else a
            lp.invalidate()
        }
    } else addr = "Waiting for GPS position"
    lp = ListPane(app, "Where Am I?") {
        val here = Gps.loc
        listOf(
            Row("Nearest Address", sub = addr, icon = "mapPin"),
            Row("Position", value = if (here != null) Fmt.coord(here.latitude, here.longitude) else "--"),
            Row("Hospitals", icon = "hospital", tap = { app.searchCategory(Cats.byName("Hospitals")) }),
            Row("Police Stations", icon = "attraction", tap = { app.searchCategory(Cats.police) }),
            Row("Fuel", icon = "fuel", tap = { app.searchCategory(Cats.byName("Fuel")) }),
            Row("Save Location", icon = "heart", tap = {
                val l = Gps.loc
                if (l == null) app.toast("Waiting for GPS position")
                else {
                    val p = Place("My Location", if (addr.startsWith("Locating") || addr.startsWith("Address")) Fmt.coord(l.latitude, l.longitude) else addr, l.latitude, l.longitude)
                    if (!Prefs.isSaved(p)) Prefs.toggleSaved(p)
                    app.toast("Location saved")
                }
            }),
            Row("Set as Home", icon = "house", tap = {
                val l = Gps.loc
                if (l == null) app.toast("Waiting for GPS position")
                else { Prefs.home = Place("Home", Fmt.coord(l.latitude, l.longitude), l.latitude, l.longitude); app.toast("Home location set") }
            })
        )
    }
    app.push(lp)
}

// ====================================================================== Start-up screen
class SplashPane(app: MainActivity) : Pane(app) {
    override fun draw0(c: Canvas) {
        fill(c, 0f, 0f, W, H, Color.BLACK)
        p.reset(); p.isAntiAlias = true; p.color = Color.WHITE; p.textSize = 46f
        p.typeface = Typeface.DEFAULT_BOLD; p.textAlign = Paint.Align.CENTER; p.letterSpacing = 0.12f
        c.drawText("GARMIN", W / 2, H / 2 + 4f, p)
        text(c, "nüvi 55", W / 2, H / 2 + 34f, 16f, 0xFFB0B0B0.toInt(), false, Paint.Align.CENTER)
        fill(c, W / 2 - 90f, H / 2 + 44f, W / 2 + 90f, H / 2 + 46f, 0xFFD9942B.toInt())
    }

    override fun onTouchEvent(e: MotionEvent): Boolean = true
}

// ====================================================================== Vehicle preview
class VehiclePreview(app: MainActivity) : SidePane(app) {
    private val t0 = SystemClock.uptimeMillis()
    init { tickMs = 140 }

    private fun btn(c: Canvas, x: Float, y: Float, w: Float, h: Float, label: String, f: () -> Unit) {
        val pr = hit(x, y, x + w, y + h, f)
        box(c, x, y, x + w, y + h, if (pr) 0xFFD3E2F2.toInt() else 0xFFF8F8F8.toInt(), if (pr) 0xFFB8CCE0.toInt() else 0xFFD0D0D0.toInt(), 0xFF888888.toInt(), 3f)
        text(c, fit(label, 12f, w - 6f), x + w / 2, y + h / 2 + 4f, 12f, 0xFF222222.toInt(), false, Paint.Align.CENTER)
    }

    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        header(c, "Vehicle Preview")
        val frames = Vehicle.frames
        if (frames.isEmpty()) {
            text(c, "No custom vehicle loaded", (52f + W) / 2, H / 2, 16f, 0xFF666666.toInt(), false, Paint.Align.CENTER)
            sidebar(c)
            return
        }
        val sec = frames[minOf(Prefs.vehicleView, frames.size - 1)]
        val n = maxOf(1, sec.size)
        val ang = (((SystemClock.uptimeMillis() - t0) / 140) % n) * (360f / n)
        val bs = minOf(140f, H - 100f)
        val bx = 66f
        val by = 36f
        fill(c, bx, by, bx + bs, by + bs, 0xFF8A9AAA.toInt())
        val bm = Vehicle.frame(ang)
        if (bm != null) {
            p.reset(); p.isFilterBitmap = true
            c.drawBitmap(bm, null, RectF(bx, by, bx + bs, by + bs), p)
        }
        val ax = bx + bs + 34f
        val ay = by + bs / 2
        c.save(); c.rotate(ang, ax, ay)
        Icons.draw(c, "up", ax, ay, 40f, 0xFF2F7FC8.toInt())
        c.restore()
        text(c, "Heading ${ang.toInt()}°", ax, ay + 44f, 11f, 0xFF444444.toInt(), false, Paint.Align.CENTER)
        if (W >= 400f) {
            val f0 = sec[0]
            text(c, "Sections: ${frames.size}", ax + 50f, by + 16f, 12f, 0xFF444444.toInt())
            text(c, "Frames: ${sec.size}", ax + 50f, by + 34f, 12f, 0xFF444444.toInt())
            text(c, "Frame size: ${f0.width} x ${f0.height}", ax + 50f, by + 52f, 12f, 0xFF444444.toInt())
            text(c, "If the car turns opposite to", ax + 50f, by + 84f, 11f, 0xFF777777.toInt())
            text(c, "the arrow, tap Flip Rotation.", ax + 50f, by + 98f, 11f, 0xFF777777.toInt())
        }
        val gap = 4f
        val bw = (W - 66f - 6f - gap * 2) / 3
        val yy = by + bs + 10f
        btn(c, 66f, yy, bw, 36f, "Flip Rotation") { Prefs.vehicleCw = !Prefs.vehicleCw }
        btn(c, 66f + bw + gap, yy, bw, 36f, if (frames.size > 1) (if (Prefs.vehicleView == 0) "View: 3D" else "View: Overhead") else "View: Only") {
            if (frames.size > 1) Prefs.vehicleView = if (Prefs.vehicleView == 0) 1 else 0
        }
        btn(c, 66f + (bw + gap) * 2, yy, bw, 36f, "Size: " + listOf("S", "M", "L")[Prefs.vehicleScale]) { Prefs.vehicleScale = (Prefs.vehicleScale + 1) % 3 }
        sidebar(c)
    }
}

// ====================================================================== GPS simulator (Settings > Navigation)
object Sim {
    private val h = Handler(Looper.getMainLooper())
    private var pos = 0.0
    private var si = 0
    private var lastRoute: Route? = null
    private var running = false
    private val tick = object : Runnable {
        override fun run() {
            step()
            if (running) h.postDelayed(this, 1000)
        }
    }

    fun update() {
        if (Prefs.sim && !running) { running = true; h.postDelayed(tick, 1000) }
        else if (!Prefs.sim && running) { running = false; h.removeCallbacks(tick) }
    }

    private fun step() {
        val r = Nav.route ?: return
        if (r !== lastRoute) { lastRoute = r; pos = 0.0; si = 0 }
        val n = r.lat.size
        if (n < 2) return
        val total = r.cum[n - 1]
        pos = minOf(total, pos + 15.0)
        while (si < n - 2 && r.cum[si + 1] < pos) si++
        val seg = maxOf(0.01, r.cum[si + 1] - r.cum[si])
        val f = ((pos - r.cum[si]) / seg).coerceIn(0.0, 1.0)
        val la = r.lat[si] + (r.lat[si + 1] - r.lat[si]) * f
        val lo = r.lon[si] + (r.lon[si + 1] - r.lon[si]) * f
        val p1 = Math.toRadians(r.lat[si])
        val p2 = Math.toRadians(r.lat[si + 1])
        val dl = Math.toRadians(r.lon[si + 1] - r.lon[si])
        val brg = Math.toDegrees(atan2(sin(dl) * cos(p2), cos(p1) * sin(p2) - sin(p1) * cos(p2) * cos(dl)))
        val l = Location("sim")
        l.latitude = la
        l.longitude = lo
        l.speed = 15f
        l.bearing = ((brg + 360.0) % 360.0).toFloat()
        l.accuracy = 5f
        l.time = System.currentTimeMillis()
        Gps.inject(l)
    }
}
