package com.nuvi.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.location.Location
import android.view.View
import android.widget.FrameLayout
import org.json.JSONArray
import org.json.JSONObject
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Polyline
import java.io.File
import java.util.Calendar

// ====================================================================== Trip Planner data
class Trip(val id: String, var name: String, var depart: Long, val stops: MutableList<Place>) {
    fun toJson(): JSONObject {
        val a = JSONArray()
        stops.forEach { a.put(it.toJson()) }
        return JSONObject().put("id", id).put("n", name).put("d", depart).put("s", a)
    }

    companion object {
        fun from(o: JSONObject): Trip {
            val l = ArrayList<Place>()
            val a = o.getJSONArray("s")
            for (i in 0 until a.length()) l.add(Place.from(a.getJSONObject(i)))
            return Trip(o.getString("id"), o.getString("n"), o.optLong("d", 0L), l)
        }
    }
}

object Trips {
    fun all(): MutableList<Trip> {
        val out = ArrayList<Trip>()
        try {
            val a = JSONArray(Prefs.getS("trips", "[]"))
            for (i in 0 until a.length()) out.add(Trip.from(a.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    private fun put(l: List<Trip>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        Prefs.putS("trips", a.toString())
    }

    fun upsert(t: Trip) {
        val l = all()
        val i = l.indexOfFirst { it.id == t.id }
        if (i >= 0) l[i] = t else l.add(0, t)
        put(l)
    }

    fun delete(id: String) = put(all().filter { it.id != id })
}

// ====================================================================== Where I've Been data
class TripRec(
    val id: String, val start: Long, val end: Long, val name: String, val addr: String,
    val lat: Double, val lon: Double, val distM: Double
) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("s", start).put("e", end).put("n", name)
        .put("a", addr).put("la", lat).put("lo", lon).put("d", distM)

    val dest: Place get() = Place(name, addr, lat, lon)

    companion object {
        fun from(o: JSONObject) = TripRec(o.getString("id"), o.getLong("s"), o.getLong("e"), o.getString("n"),
            o.optString("a"), o.getDouble("la"), o.getDouble("lo"), o.getDouble("d"))
    }
}

/** Records the GPS track of every navigated trip. */
object TripLog {
    private lateinit var dir: File
    private var dest: Place? = null
    private var title = ""
    private var startMs = 0L
    private var dist = 0.0
    private val pts = ArrayList<DoubleArray>()

    fun init(ctx: Context) {
        dir = File(ctx.filesDir, "tracks")
        dir.mkdirs()
    }

    fun begin(d: Place, name: String?) {
        end()
        dest = d
        title = name ?: d.name
        startMs = System.currentTimeMillis()
        dist = 0.0
        pts.clear()
    }

    fun add(l: Location) {
        if (dest == null) return
        if (pts.isEmpty()) pts.add(doubleArrayOf(l.latitude, l.longitude))
        else {
            val p = pts[pts.size - 1]
            val d = hav(p[0], p[1], l.latitude, l.longitude)
            if (d >= 25) { pts.add(doubleArrayOf(l.latitude, l.longitude)); dist += d }
        }
        Eco.sample(l)
    }

    fun end() {
        val d = dest ?: return
        if (dist > 100 && pts.size >= 2) {
            val id = startMs.toString()
            try {
                File(dir, "$id.csv").writeText(pts.joinToString("\n") { "${it[0]},${it[1]}" })
                val l = records().toMutableList()
                l.add(0, TripRec(id, startMs, System.currentTimeMillis(), title, d.addr, d.lat, d.lon, dist))
                val a = JSONArray()
                l.take(100).forEach { a.put(it.toJson()) }
                Prefs.putS("history", a.toString())
            } catch (e: Exception) { }
        }
        Eco.flush()
        dest = null
        pts.clear()
    }

    fun records(): List<TripRec> {
        val out = ArrayList<TripRec>()
        try {
            val a = JSONArray(Prefs.getS("history", "[]"))
            for (i in 0 until a.length()) out.add(TripRec.from(a.getJSONObject(i)))
        } catch (e: Exception) { }
        return out
    }

    fun track(id: String): List<DoubleArray> {
        val out = ArrayList<DoubleArray>()
        try {
            File(dir, "$id.csv").forEachLine { ln ->
                val p = ln.split(",")
                if (p.size == 2) out.add(doubleArrayOf(p[0].toDouble(), p[1].toDouble()))
            }
        } catch (e: Exception) { }
        return out
    }

    fun delete(id: String) {
        File(dir, "$id.csv").delete()
        val a = JSONArray()
        records().filter { it.id != id }.forEach { a.put(it.toJson()) }
        Prefs.putS("history", a.toString())
    }
}

// ====================================================================== Trip Planner screens
fun openTripPlanner(app: MainActivity) {
    app.push(ListPane(app, "Trip Planner") {
        val l = ArrayList<Row>()
        l.add(Row("New Trip", icon = "plus", tap = {
            val t = Trip(System.currentTimeMillis().toString(), "Trip ${Trips.all().size + 1}", 0L, ArrayList<Place>())
            Trips.upsert(t)
            openTripEditor(app, t)
        }))
        for (t in Trips.all()) {
            val sub = "${t.stops.size} stop" + (if (t.stops.size == 1) "" else "s") +
                (if (t.depart > 0) "  ·  " + Fmt.dateTime(t.depart) else "")
            l.add(Row(t.name, sub, icon = "trip", tap = { openTripEditor(app, t) }))
        }
        l
    })
}

fun openTripEditor(app: MainActivity, trip: Trip) {
    lateinit var self: ListPane
    self = ListPane(app, "Edit Trip") {
        val l = ArrayList<Row>()
        l.add(Row("Name", value = trip.name, tap = {
            app.push(KeyPane(app, "Trip name", trip.name) { v ->
                if (v.isNotBlank()) trip.name = v.trim()
                Trips.upsert(trip)
                app.pop()
            })
        }))
        l.add(Row("Departure", value = if (trip.depart > 0) Fmt.dateTime(trip.depart) else "Not set", tap = {
            app.pickDateTime(trip.depart) { t -> trip.depart = t; Trips.upsert(trip) }
        }))
        if (trip.depart > 0) {
            l.add(Row("Clear Departure", tap = { trip.depart = 0L; Trips.upsert(trip) }))
            val dt = trip.depart - System.currentTimeMillis()
            if (dt in 0..86400000L) l.add(Row("Set Alarm Reminder", icon = "clock", tap = { app.setAlarm(trip) }))
        }
        trip.stops.forEachIndexed { i, s ->
            l.add(Row("${i + 1}. ${s.name}", s.addr, icon = "mapPin", tap = { openStopMenu(app, trip, i) }))
        }
        l.add(Row("Add Stop", icon = "plus", tap = { openAddStop(app, trip, self) }))
        if (trip.stops.isNotEmpty()) l.add(Row("Start Trip", icon = "mapPin", tap = { Trips.upsert(trip); app.startTrip(trip) }))
        l.add(Row("Delete Trip", icon = "stop", tap = { Trips.delete(trip.id); app.pop() }))
        l
    }
    app.push(self)
}

private fun openStopMenu(app: MainActivity, trip: Trip, i: Int) {
    app.push(ListPane(app, "Stop ${i + 1}") {
        val l = ArrayList<Row>()
        if (i > 0) l.add(Row("Move Up", icon = "up", tap = { java.util.Collections.swap(trip.stops, i, i - 1); Trips.upsert(trip); app.pop() }))
        if (i < trip.stops.size - 1) l.add(Row("Move Down", icon = "down", tap = { java.util.Collections.swap(trip.stops, i, i + 1); Trips.upsert(trip); app.pop() }))
        l.add(Row("Remove", icon = "stop", tap = { trip.stops.removeAt(i); Trips.upsert(trip); app.pop() }))
        l.add(Row("View Place", icon = "mapPin", tap = { app.showPlace(trip.stops[i]) }))
        l
    })
}

private fun openAddStop(app: MainActivity, trip: Trip, editor: View) {
    val add = { pl: Place -> trip.stops.add(pl); Trips.upsert(trip); app.popTo(editor) }
    app.push(ListPane(app, "Add Stop") {
        listOf(
            Row("Search", icon = "search", tap = { app.openSearch(add) }),
            Row("Address", icon = "address", tap = { app.openAddress(add) }),
            Row("Saved", icon = "heart", tap = { app.showResults("Saved", Prefs.places("saved"), add) }),
            Row("Recently Found", icon = "clock", tap = { app.showResults("Recently Found", Prefs.places("recent"), add) }),
            Row("Home", icon = "house", tap = {
                val h = Prefs.home
                if (h == null) app.toast("No home location set") else add(h)
            }),
            Row("Current Location", icon = "mapPin", tap = {
                val l = Gps.loc
                if (l == null) app.toast("Waiting for GPS position")
                else add(Place("Current Location", Fmt.coord(l.latitude, l.longitude), l.latitude, l.longitude))
            })
        )
    })
}

// ====================================================================== Where I've Been screens
fun openWhereIveBeen(app: MainActivity) {
    app.push(ListPane(app, "Where I've Been") {
        val recs = TripLog.records()
        if (recs.isEmpty()) listOf(Row("No trips logged yet", sub = "Trips are recorded while you navigate a route"))
        else {
            val l = ArrayList<Row>()
            l.add(Row("All Trips on Map", icon = "mapPin", tap = { app.push(TripMapScreen(app, recs.take(20), "All Trips")) }))
            for (r in recs) {
                l.add(Row(r.name, Fmt.dateTime(r.start) + "  ·  " + Fmt.dist(r.distM), icon = "been", tap = { openTripDetail(app, r) }))
            }
            l
        }
    })
}

private fun openTripDetail(app: MainActivity, r: TripRec) {
    app.push(ListPane(app, r.name) {
        listOf(
            Row("View on Map", icon = "mapPin", tap = { app.push(TripMapScreen(app, listOf(r), r.name)) }),
            Row("Navigate Again", icon = "trip", tap = { app.startNav(r.dest) }),
            Row("Date", value = Fmt.dateTime(r.start)),
            Row("Distance", value = Fmt.dist(r.distM)),
            Row("Duration", value = Fmt.duration((r.end - r.start) / 1000.0)),
            Row("Delete From Log", icon = "stop", tap = { TripLog.delete(r.id); app.pop() })
        )
    })
}

class TripMapScreen(private val app: MainActivity, recs: List<TripRec>, title: String) : FrameLayout(app) {
    private val map = MapView(app)

    init {
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        map.isTilesScaledToDpi = true
        val all = ArrayList<GeoPoint>()
        for (r in recs) {
            val pts = TripLog.track(r.id).map { GeoPoint(it[0], it[1]) }
            if (pts.size < 2) continue
            val pl = Polyline()
            pl.setPoints(pts)
            pl.outlinePaint.color = 0xFFD94BA6.toInt()
            pl.outlinePaint.strokeWidth = DENSITY * 5f
            pl.outlinePaint.strokeCap = Paint.Cap.ROUND
            map.overlays.add(pl)
            all.addAll(pts)
        }
        map.controller.setZoom(3.0)
        addView(map, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val again: (() -> Unit)? = if (recs.size == 1) ({ app.startNav(recs[0].dest) }) else null
        addView(TripMapHud(app, title, again, { map.controller.zoomIn() }, { map.controller.zoomOut() }),
            LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        if (all.isNotEmpty()) {
            map.post {
                try { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(all), false, (DENSITY * 48).toInt()) } catch (e: Exception) { }
            }
        }
    }
}

class TripMapHud(
    private val app: MainActivity, private val title: String, private val again: (() -> Unit)?,
    private val zoomIn: () -> Unit, private val zoomOut: () -> Unit
) : Pane(app) {
    override fun draw0(c: Canvas) {
        val by = H - 44f
        val d1 = 0xFF3F5063.toInt()
        val d2 = 0xFF26323E.toInt()
        val ink = 0xFF1A1A1A.toInt()
        box(c, 52f, by, W, H, 0xFFF3F3F3.toInt(), 0xFFC8CCD0.toInt(), 0xFF7C8084.toInt())
        text(c, fit(title, 16f, W - 230f, true), 64f, H - 16f, 16f, ink, true)
        if (again != null) {
            val g = hit(W - 122f, by + 6f, W - 6f, H - 6f) { again.invoke() }
            box(c, W - 122f, by + 6f, W - 6f, H - 6f, if (g) 0xFF3FB35A.toInt() else 0xFF2E9A45.toInt(), 0xFF1E7A33.toInt(), 0xFF145A24.toInt(), 3f)
            text(c, "Go Again", W - 64f, H - 16f, 15f, Color.WHITE, true, Paint.Align.CENTER)
        }
        val b = hit(0f, by, 52f, H) { app.pop() }
        box(c, 0f, by, 52f, H, if (b) 0xFF5A7088.toInt() else d1, d2, 0xFF0E1822.toInt())
        Icons.draw(c, "back", 26f, by + 22f, 28f, Color.WHITE)
        p.reset(); p.isAntiAlias = true; p.color = 0xAAF2F2F2.toInt()
        c.drawRoundRect(android.graphics.RectF(4f, 20f, 38f, 100f), 3f, 3f, p)
        hit(4f, 20f, 38f, 60f) { zoomIn() }
        hit(4f, 60f, 38f, 100f) { zoomOut() }
        Icons.draw(c, "plus", 21f, 40f, 24f, 0xFF3A3A3A.toInt())
        Icons.draw(c, "minus", 21f, 80f, 24f, 0xFF3A3A3A.toInt())
        fill(c, W - 96f, by - 12f, W, by, 0xAAFFFFFF.toInt())
        text(c, "© OpenStreetMap", W - 3f, by - 3f, 8f, 0xFF333333.toInt(), false, Paint.Align.RIGHT)
    }
}
