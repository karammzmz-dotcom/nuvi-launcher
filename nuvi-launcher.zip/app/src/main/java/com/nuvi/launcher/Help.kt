package com.nuvi.launcher

import android.graphics.Canvas
import android.graphics.Paint

private val HELP: List<Pair<String, String>> = listOf(
    "Getting Started" to
        "Tap Where To? to find a destination, or View Map to see the map and your position.\n" +
        "The Stop, Apps, Volume and Settings buttons are at the bottom of the home screen (right side in portrait).\n" +
        "Allow location access when asked, then wait for the satellite bars at the top left to fill. Navigation needs a GPS fix and an internet connection.",
    "Where To?" to
        "The Where To? screen has quick buttons for Go Home, Address, Restaurants, Gas Stations, Shopping, Parking, Lodging, Hospitals, ATMs, Cities, Coordinates and Intersections. Use the up and down arrows on the left to see more buttons.\n" +
        "Categories, Saved and Recent are on the right. Tap Enter Search to type a name or address.\n" +
        "The Searching near box switches between your current location and your Home location.",
    "Searching for a Place" to
        "Tap Enter Search and type a business, place name or address. Suggestions appear above the keyboard as you type; tap one to open it, or press the green search key for a full list sorted by distance.\n" +
        "The globe key switches between English and Arabic keys. The &?% key shows symbols and numbers.\n" +
        "Search needs an internet connection.",
    "Address Search" to
        "Choose Where To? > Address. Fill in Country, City, Street and House Number, then tap Search. You can leave the house number blank. Pick a result to see its details, then tap Go!.",
    "Categories, Saved and Recent" to
        "Categories searches near you for food, fuel, lodging, shopping, parking, hospitals, ATMs, restaurants and attractions.\n" +
        "Open any place and tap Save to keep it in Saved. Tap Set Home to make it your home location. Places you open or navigate to appear in Recently Found.",
    "Navigating a Route" to
        "Open a place and tap Go!. The map shows a turn panel at the top with the distance to the next turn and the street name. Tap the top bar to see the full turn list.\n" +
        "At the bottom you see Speed, the current road and an Arrival panel. Tap the Arrival panel to switch between arrival time, remaining distance and time left.\n" +
        "If you leave the route, the route is recalculated. Voice prompts can be turned off in Settings > Navigation Settings. Open the menu button on the map and choose Stop Route to cancel.",
    "Using the Map" to
        "Use + and - to zoom. Drag the map to look around; tap Re-center to follow your position again.\n" +
        "Touch and hold a spot on the map to drop a pin and open its details.\n" +
        "The map keeps working only while this app is on screen. If you open another app, navigation pauses.",
    "Map Layers and Colors" to
        "The map is the OpenStreetMap base map. Settings > Map Settings lets you choose Track Up or North Up, and the map colors: Auto, Day or Night (Auto switches at sunset hours).\n" +
        "You can also change the vehicle icon, see Vehicle Icon. Extra data layers such as traffic or 3D buildings are not available.",
    "Vehicle Icon (.srf)" to
        "You can use Garmin vehicle files (.srf) as your position marker. Go to Settings > Map Settings > Vehicle > Import .srf File and choose a file from your phone.\n" +
        "View: choose the overhead or 3D picture stored in the file. Rotation: if the vehicle turns the wrong way, switch between clockwise and counter-clockwise. Size changes how big it is drawn.\n" +
        "Choose Remove Custom Vehicle to go back to the default car.",
    "Trip Planner" to
        "Apps > Trip Planner lets you build a trip with several stops. Tap New Trip, then Add Stop to search, enter an address, or choose a saved, recent, home or current location.\n" +
        "Tap a stop to move it up or down or to remove it. Set a departure date and time; for the next 24 hours you can also set an alarm reminder in your clock app.\n" +
        "Trips are saved automatically. Tap Start Trip to navigate to each stop in order.",
    "Where I've Been" to
        "Apps > Where I've Been lists the trips recorded while you navigated, with date, distance and a map of the route you drove.\n" +
        "Open a trip to view it on the map, Navigate Again to the same destination, or delete it from the log.",
    "ecoRoute" to
        "Apps > ecoRoute estimates fuel use and cost. First set your Vehicle Profile: fuel type, fuel economy and fuel price. Calibrate Fuel Economy calculates your real economy from a fill-up.\n" +
        "Mileage Report shows distance, fuel and cost for today, the last 7 days and each trip. Trip Fuel Cost estimates the remaining route.\n" +
        "ecoChallenge scores your driving from 0 to 100 for speed, acceleration and braking, using GPS data collected while you navigate.",
    "Settings" to
        "Display: orientation, hide the Android bars (launcher mode) and key tones. Brightness: set screen brightness for this app. Language: keyboard language and voice accent. Units: kilometers or miles. Time: 12 or 24 hour. Map Settings, Navigation Settings (avoid highways and tolls, voice, home location), Bluetooth, GPS Information and About.",
    "Troubleshooting" to
        "No position: go outside or near a window and wait. Check the GPS Information screen in Settings.\n" +
        "Blank map: check the internet connection; the map needs data to load tiles.\n" +
        "Search does not work: check the internet connection and try again, the free search servers can be busy.\n" +
        "No voice: raise the volume (Volume on the home screen) and check that Voice Guidance is on.\n" +
        "To make this the home app, choose Settings > About > Set as Default Home App.",
    "About" to
        "Map data is from OpenStreetMap contributors. Routing uses OSRM. Searching uses Photon, Nominatim and Overpass. These are free public services and need an internet connection."
)

fun openHelp(app: MainActivity) {
    app.push(ListPane(app, "Help") {
        val l = ArrayList<Row>()
        l.add(Row("Search Help", icon = "search", tap = { openHelpSearch(app) }))
        for (t in HELP) l.add(Row(t.first, icon = "help", tap = { app.push(TextPane(app, t.first, t.second)) }))
        l
    })
}

private fun openHelpSearch(app: MainActivity) {
    app.push(KeyPane(app, "Type a word to search the help", "") { q ->
        val words = q.lowercase().split(" ").filter { it.isNotBlank() }
        val hits = HELP.filter { t -> words.all { w -> (t.first + " " + t.second).lowercase().contains(w) } }
        if (hits.isEmpty()) app.toast("No help topics found")
        else app.push(ListPane(app, "Help: $q") {
            hits.map { t -> Row(t.first, t.second.substringBefore("\n").take(90), icon = "help", tap = { app.push(TextPane(app, t.first, t.second)) }) }
        })
    })
}

class TextPane(app: MainActivity, private val title: String, private val body: String) : SidePane(app) {
    private var page = 0
    private var lines: List<String> = emptyList()
    private var lastW = 0f

    private fun wrap(maxW: Float): List<String> {
        val out = ArrayList<String>()
        for (para in body.split("\n")) {
            if (para.isBlank()) { out.add(""); continue }
            var rest = para.trim()
            while (rest.isNotEmpty()) {
                p.reset(); p.textSize = 14f
                val n = p.breakText(rest, true, maxW, null)
                if (n >= rest.length) { out.add(rest); break }
                var cut = rest.lastIndexOf(' ', n - 1)
                if (cut <= 0) cut = maxOf(1, n)
                out.add(rest.substring(0, cut).trim())
                rest = rest.substring(cut).trim()
            }
            out.add("")
        }
        return out
    }

    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        val maxW = W - 74f
        if (lastW != maxW) { lines = wrap(maxW); lastW = maxW }
        val lh = 19f
        val top = 30f
        val per = maxOf(3, ((H - top - 8f) / lh).toInt())
        val pages = maxOf(1, (lines.size + per - 1) / per)
        page = page.coerceIn(0, pages - 1)
        canUp = page > 0
        canDown = page < pages - 1
        onUp = { page--; invalidate() }
        onDown = { page++; invalidate() }
        for (i in 0 until per) {
            val k = page * per + i
            if (k >= lines.size) break
            text(c, lines[k], 62f, top + 16f + i * lh, 14f, 0xFF1E1E1E.toInt())
        }
        header(c, title)
        text(c, "${page + 1}/$pages", W - 8f, H - 5f, 10f, 0xFF888888.toInt(), false, Paint.Align.RIGHT)
        sidebar(c)
    }
}
