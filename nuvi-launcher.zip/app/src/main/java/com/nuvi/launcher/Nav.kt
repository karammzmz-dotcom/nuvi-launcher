package com.nuvi.launcher

import android.location.Location

object Nav {
    var route: Route? = null
    var dest: Place? = null
    var stepIdx = 1
    var distToTurn = 0.0
    var remaining = 0.0
    var remDur = 0.0
    var eta = 0L
    var calculating = false
    var onChange: (() -> Unit)? = null
    var msg: ((String) -> Unit)? = null
    var speaker: ((String) -> Unit)? = null

    private var idx = 0
    private var off = 0
    private var lastStep = -1
    private var farSaid = false
    private var nearSaid = false

    fun start(d: Place) {
        dest = d
        route = null
        onChange?.invoke()
        calc()
    }

    fun stop() {
        route = null
        dest = null
        calculating = false
        onChange?.invoke()
    }

    fun calc() {
        val d = dest ?: return
        val l = Gps.loc
        if (l == null) { msg?.invoke("Waiting for GPS signal"); return }
        if (calculating) return
        calculating = true
        onChange?.invoke()
        Net.async({ Net.route(l.latitude, l.longitude, d.lat, d.lon, Prefs.avoidHw, Prefs.avoidToll) }) { r ->
            calculating = false
            if (dest === d) {
                r.onSuccess { rt ->
                    route = rt
                    idx = 0
                    off = 0
                    lastStep = -1
                    stepIdx = minOf(1, rt.steps.size - 1)
                    Sound.chime()
                    rt.note?.let { msg?.invoke(it) }
                    onLoc(l)
                }.onFailure {
                    msg?.invoke("Route failed: " + (it.message ?: "unknown error"))
                    if (route == null) dest = null
                }
            }
            onChange?.invoke()
        }
    }

    fun onLoc(l: Location) {
        val r = route
        if (r == null) {
            if (dest != null && !calculating) calc()
            return
        }
        var best = idx
        var bd = Double.MAX_VALUE
        fun scan(a: Int, b: Int) {
            for (i in a..b) {
                val d = hav(l.latitude, l.longitude, r.lat[i], r.lon[i])
                if (d < bd) { bd = d; best = i }
            }
        }
        scan(maxOf(0, idx - 3), minOf(r.lat.size - 1, idx + 600))
        if (bd > 60) scan(0, r.lat.size - 1)
        if (bd > 60) {
            off++
            if (off >= 3) {
                off = 0
                msg?.invoke("Recalculating")
                speaker?.invoke("Recalculating")
                calc()
            }
        } else {
            off = 0
            idx = best
        }
        val total = r.cum[r.cum.size - 1]
        remaining = (total - r.cum[idx]).coerceAtLeast(0.0)
        remDur = r.dur * remaining / maxOf(total, 1.0)
        eta = System.currentTimeMillis() + (remDur * 1000).toLong()
        while (stepIdx < r.steps.size - 1 && r.steps[stepIdx].idx < idx) stepIdx++
        val st = r.steps[stepIdx]
        distToTurn = (r.cum[st.idx] - r.cum[idx]).coerceAtLeast(0.0)

        if (stepIdx != lastStep) { lastStep = stepIdx; farSaid = false; nearSaid = false }
        if (stepIdx == r.steps.size - 1 && distToTurn < 35) {
            msg?.invoke("You have arrived")
            speaker?.invoke("You have arrived at your destination")
            stop()
            return
        }
        if (!nearSaid && distToTurn < 150) {
            nearSaid = true; farSaid = true
            speaker?.invoke(st.text)
        } else if (!farSaid && distToTurn < 900) {
            farSaid = true
            speaker?.invoke("In ${Fmt.spoken(distToTurn)}, ${st.text}")
        }
        onChange?.invoke()
    }
}
