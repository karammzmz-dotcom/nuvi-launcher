package com.nuvi.launcher

import android.location.Location
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

/** ecoRoute: fuel economy profile, trip cost estimates, mileage report and driving score (ecoChallenge). */
object Eco {
    var moving = 0.0
    var acc = 0.0
    var brake = 0.0
    var over = 0.0
    var limitKmh = 0
    private var pv = 0f
    private var pt = 0L

    fun load() {
        try {
            val o = JSONObject(Prefs.getS("eco", "{}"))
            moving = o.optDouble("m", 0.0); acc = o.optDouble("a", 0.0)
            brake = o.optDouble("b", 0.0); over = o.optDouble("o", 0.0)
        } catch (e: Exception) { }
    }

    fun save() {
        Prefs.putS("eco", JSONObject().put("m", moving).put("a", acc).put("b", brake).put("o", over).toString())
    }

    fun reset() { moving = 0.0; acc = 0.0; brake = 0.0; over = 0.0; save() }

    fun flush() { save(); pt = 0L }

    fun sample(l: Location) {
        val v = if (l.hasSpeed()) l.speed else 0f
        val t = l.time
        if (pt > 0) {
            val dt = (t - pt) / 1000.0
            if (dt in 0.3..6.0 && v > 1f) {
                moving += dt
                val a = (v - pv) / dt
                if (a > 2.0) acc += dt
                if (a < -2.5) brake += dt
                val lim = if (limitKmh > 0) limitKmh else 130
                if (v * 3.6 > lim + 5) over += dt
            }
        }
        pv = v
        pt = t
    }

    private fun score(x: Double): Int = if (moving < 30) -1 else (100 - minOf(100.0, 400.0 * x / moving)).toInt()
    fun speedScore() = score(over)
    fun accScore() = score(acc)
    fun brakeScore() = score(brake)
    fun overall(): Int {
        val s = listOf(speedScore(), accScore(), brakeScore())
        return if (s.any { it < 0 }) -1 else s.average().toInt()
    }

    fun scoreStr(s: Int) = if (s < 0) "--" else "$s / 100"

    // ---- unit helpers (economy is stored as litres per 100 km, price per litre)
    fun econ(): String =
        if (Prefs.miles) String.format(Locale.US, "%.1f mpg", 235.215 / Prefs.ecoL100)
        else String.format(Locale.US, "%.1f L/100 km", Prefs.ecoL100.toDouble())

    fun fuel(liters: Double): String =
        if (Prefs.miles) String.format(Locale.US, "%.2f gal", liters / 3.78541) else String.format(Locale.US, "%.2f L", liters)

    fun priceStr(): String =
        if (Prefs.miles) String.format(Locale.US, "%.2f per gal", Prefs.fuelPrice * 3.78541)
        else String.format(Locale.US, "%.2f per L", Prefs.fuelPrice.toDouble())

    fun litersFor(distM: Double) = distM / 1000.0 * Prefs.ecoL100 / 100.0
    fun cost(liters: Double): String = String.format(Locale.US, "%.2f", liters * Prefs.fuelPrice)
    fun fuelTypeName() = listOf("Gasoline", "Diesel", "Other")[Prefs.fuelType]
}

fun openEcoRoute(app: MainActivity) {
    lateinit var self: ListPane
    self = ListPane(app, "ecoRoute") {
        listOf(
            Row("ecoChallenge", value = Eco.scoreStr(Eco.overall()), icon = "eco", tap = { openEcoChallenge(app) }),
            Row("Mileage Report", tap = { openMileage(app) }),
            Row("Trip Fuel Cost", tap = { openFuelCost(app) }),
            Row("Vehicle Profile", value = Eco.econ(), tap = { openVehicleProfile(app) }),
            Row("Calibrate Fuel Economy", tap = { calibrateEco(app, self) })
        )
    }
    app.push(self)
}

private fun openEcoChallenge(app: MainActivity) {
    app.push(ListPane(app, "ecoChallenge") {
        listOf(
            Row("Overall Score", value = Eco.scoreStr(Eco.overall()), icon = "eco"),
            Row("Speed", sub = "Time spent above the speed limit", value = Eco.scoreStr(Eco.speedScore())),
            Row("Acceleration", sub = "Hard acceleration events", value = Eco.scoreStr(Eco.accScore())),
            Row("Braking", sub = "Hard braking events", value = Eco.scoreStr(Eco.brakeScore())),
            Row("Driving Time Scored", value = Fmt.duration(Eco.moving)),
            Row("Reset Scores", icon = "stop", tap = { Eco.reset(); app.toast("ecoChallenge reset") })
        )
    })
}

private fun openMileage(app: MainActivity) {
    app.push(ListPane(app, "Mileage Report") {
        val recs = TripLog.records()
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0)
        val today = cal.timeInMillis
        val week = System.currentTimeMillis() - 7 * 86400000L
        fun total(since: Long, label: String): Row {
            val d = recs.filter { it.start >= since }.sumOf { it.distM }
            return Row(label, value = Fmt.dist(d) + "  ·  " + Eco.cost(Eco.litersFor(d)), icon = "eco")
        }
        val l = ArrayList<Row>()
        l.add(total(today, "Today"))
        l.add(total(week, "Last 7 Days"))
        l.add(total(0L, "All Trips"))
        for (r in recs) {
            l.add(Row(r.name, Fmt.dateTime(r.start) + "  ·  " + Eco.fuel(Eco.litersFor(r.distM)),
                value = Fmt.dist(r.distM) + "  ·  " + Eco.cost(Eco.litersFor(r.distM))))
        }
        if (recs.isEmpty()) l.add(Row("No trips logged yet", sub = "Costs use your Vehicle Profile"))
        l
    })
}

private fun openFuelCost(app: MainActivity) {
    app.push(ListPane(app, "Trip Fuel Cost") {
        val l = ArrayList<Row>()
        if (Nav.route != null) {
            val liters = Eco.litersFor(Nav.remaining)
            l.add(Row("Remaining Route", value = Fmt.dist(Nav.remaining)))
            l.add(Row("Estimated Fuel", value = Eco.fuel(liters)))
            l.add(Row("Estimated Cost", value = Eco.cost(liters), icon = "eco"))
        } else {
            l.add(Row("No active route", sub = "Start navigation to estimate fuel for the trip"))
        }
        l.add(Row("Fuel Economy", value = Eco.econ()))
        l.add(Row("Fuel Price", value = Eco.priceStr()))
        l
    })
}

private fun openVehicleProfile(app: MainActivity) {
    app.push(ListPane(app, "Vehicle Profile") {
        listOf(
            Row("Fuel Type", value = Eco.fuelTypeName(), tap = { Prefs.fuelType = (Prefs.fuelType + 1) % 3 }),
            Row("Fuel Economy", value = Eco.econ(), tap = {
                app.push(KeyPane(app, if (Prefs.miles) "Fuel economy in mpg" else "Fuel economy in L/100 km", "") { v ->
                    val x = v.replace(',', '.').toDoubleOrNull()
                    val l100 = if (x == null || x <= 0) null else if (Prefs.miles) 235.215 / x else x
                    if (l100 == null || l100 < 1 || l100 > 80) app.toast("Enter a realistic number")
                    else { Prefs.ecoL100 = l100.toFloat(); app.pop() }
                })
            }),
            Row("Fuel Price", value = Eco.priceStr(), tap = {
                app.push(KeyPane(app, if (Prefs.miles) "Price per gallon" else "Price per litre", "") { v ->
                    val x = v.replace(',', '.').toDoubleOrNull()
                    if (x == null || x <= 0) app.toast("Enter a price")
                    else { Prefs.fuelPrice = (if (Prefs.miles) x / 3.78541 else x).toFloat(); app.pop() }
                })
            })
        )
    })
}

private fun calibrateEco(app: MainActivity, root: ListPane) {
    val fuelUnit = if (Prefs.miles) "gallons" else "litres"
    val distUnit = if (Prefs.miles) "miles" else "km"
    app.push(KeyPane(app, "Fuel added at the last fill-up ($fuelUnit)", "") { f ->
        val fuel = f.replace(',', '.').toDoubleOrNull()
        if (fuel == null || fuel <= 0) app.toast("Enter the fuel amount")
        else app.push(KeyPane(app, "Distance driven since previous fill-up ($distUnit)", "") { d ->
            val dist = d.replace(',', '.').toDoubleOrNull()
            if (dist == null || dist <= 0) app.toast("Enter the distance")
            else {
                val liters = if (Prefs.miles) fuel * 3.78541 else fuel
                val km = if (Prefs.miles) dist * 1.609344 else dist
                val l100 = liters / km * 100
                if (l100 < 1 || l100 > 80) app.toast("Those numbers look wrong")
                else { Prefs.ecoL100 = l100.toFloat(); app.popTo(root); app.toast("Fuel economy: " + Eco.econ()) }
            }
        })
    })
}
