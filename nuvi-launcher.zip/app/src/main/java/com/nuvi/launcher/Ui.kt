package com.nuvi.launcher

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View

var DENSITY = 1f

/** Condensed system font (no asset bundling needed) - closer to the real device's chunky sans than stock Roboto. */
private val FONT_REGULAR: Typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
private val FONT_BOLD: Typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)

interface Screen {
    fun onShow()
    fun onHide()
}

class Row(
    val title: String,
    val sub: String? = null,
    val value: String? = null,
    val icon: String? = null,
    val img: Drawable? = null,
    val tap: (() -> Unit)? = null
)

/**
 * Immediate-mode view. Everything is drawn in "logical units" where the short screen side is
 * 272 units (the real nuvi 55 is 480x272), so the layout scales to any phone or tablet.
 */
open class Pane(ctx: Context) : View(ctx) {
    private class Hit(val r: RectF, val f: () -> Unit)

    private val hits = ArrayList<Hit>()
    private var down: Hit? = null
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected var tickMs = 0L
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            if (tickMs > 0) postDelayed(this, tickMs)
        }
    }
    var W = 480f
    var H = 272f
    var u = 1f
    private var offX = 0f
    private var offY = 0f

    /**
     * When true (the default), the pane is rendered at the real nüvi's fixed 480x272 aspect
     * ratio, scaled as large as fits and centered with letterbox/pillarbox bars - rather than
     * stretched to the phone's actual (usually much wider) aspect. MapHud overrides this to
     * false so its chrome still spans the full, edge-to-edge live map underneath it.
     */
    protected open val letterbox: Boolean get() = true

    open fun draw0(c: Canvas) {}

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (tickMs > 0) postDelayed(tick, tickMs)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeCallbacks(tick)
    }

    override fun onDraw(c: Canvas) {
        if (width == 0 || height == 0) return
        if (letterbox) {
            u = minOf(width / 480f, height / 272f)
            W = 480f
            H = 272f
        } else {
            u = minOf(width, height) / 272f
            W = width / u
            H = height / u
        }
        offX = (width - W * u) / 2f
        offY = (height - H * u) / 2f
        hits.clear()
        if (offX > 0.5f || offY > 0.5f) {
            p.reset(); p.color = Color.BLACK
            c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), p)
        }
        c.save()
        c.translate(offX, offY)
        c.scale(u, u)
        draw0(c)
        c.restore()
    }

    /** Registers a touch target (logical units); returns true while it is being pressed. */
    fun hit(x0: Float, y0: Float, x1: Float, y1: Float, f: () -> Unit): Boolean {
        val r = RectF(x0, y0, x1, y1)
        hits.add(Hit(r, f))
        return down?.r == r
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = (e.x - offX) / u
        val y = (e.y - offY) / u
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                down = hits.lastOrNull { it.r.contains(x, y) } ?: return false
                if (Prefs.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val d = down ?: return false
                if (!d.r.contains(x, y)) { down = null; invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                val d = down
                down = null
                invalidate()
                if (d != null && d.r.contains(x, y)) { Sound.click(); d.f() }
            }
            MotionEvent.ACTION_CANCEL -> { down = null; invalidate() }
        }
        return true
    }

    fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, align: Paint.Align = Paint.Align.LEFT) {
        p.reset(); p.isAntiAlias = true
        p.textSize = size; p.color = color; p.textAlign = align
        p.typeface = if (bold) FONT_BOLD else FONT_REGULAR
        c.drawText(s, x, y, p)
    }

    fun fit(s: String, size: Float, maxW: Float, bold: Boolean = false): String {
        p.reset(); p.isAntiAlias = true
        p.textSize = size
        p.typeface = if (bold) FONT_BOLD else FONT_REGULAR
        val n = p.breakText(s, true, maxW, null)
        return if (n >= s.length) s else s.substring(0, maxOf(0, n - 1)) + "…"
    }

    fun fill(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        p.reset(); p.color = color
        c.drawRect(l, t, r, b, p)
    }

    fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, top: Int, bot: Int, stroke: Int = 0, rad: Float = 0f) {
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, t, 0f, b, top, bot, Shader.TileMode.CLAMP)
        c.drawRoundRect(l, t, r, b, rad, rad, p)
        if (stroke != 0) {
            p.reset(); p.isAntiAlias = true
            p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = stroke
            c.drawRoundRect(l + .5f, t + .5f, r - .5f, b - .5f, rad, rad, p)
        }
    }

    fun poly(c: Canvas, path: Path, top: Int, bot: Int, y0: Float, y1: Float, stroke: Int) {
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, y0, 0f, y1, top, bot, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = stroke
        c.drawPath(path, p)
    }

    /** value + stacked 2-letter unit (like the "m/h" of the real device) */
    fun valueUnit(c: Canvas, value: String, unit: String, cx: Float, base: Float, size: Float, color: Int) {
        p.reset(); p.isAntiAlias = true; p.textSize = size; p.typeface = FONT_BOLD
        val vw = p.measureText(value)
        val us = size * 0.38f
        val total = vw + us * 0.9f
        val x = cx - total / 2
        text(c, value, x, base, size, color, true)
        if (unit.length == 2) {
            text(c, unit.substring(0, 1), x + vw + 1f, base - size * 0.42f, us, color, true)
            text(c, unit.substring(1, 2), x + vw + 1f, base - 1f, us, color, true)
        } else {
            text(c, unit, x + vw + 1f, base - 1f, us, color, true)
        }
    }
}

/** Dark left sidebar (menu / up / down / back) used by the Garmin list-style screens. */
open class SidePane(val app: MainActivity) : Pane(app) {
    var canUp = false
    var canDown = false
    var onUp: () -> Unit = {}
    var onDown: () -> Unit = {}

    /** [pageLabel] (e.g. "2/5"), when given, is shown between the up/down arrows so multi-page lists are less disorienting. */
    fun sidebar(c: Canvas, pageLabel: String? = null) {
        fill(c, 0f, 0f, 50f, H, 0xFF1E1E1E.toInt())
        fill(c, 50f, 0f, 52f, H, 0xFFD9942B.toInt())
        val m = hit(0f, 0f, 50f, 56f) { app.goHome() }
        Icons.draw(c, "menu", 25f, 28f, 26f, if (m) 0xFF999999.toInt() else Color.WHITE)
        val ya = H * 0.36f
        val yb = H * 0.56f
        if (canUp) hit(0f, ya - 28f, 50f, ya + 28f) { onUp() }
        if (canDown) hit(0f, yb - 28f, 50f, yb + 28f) { onDown() }
        Icons.draw(c, "up", 25f, ya, 26f, if (canUp) 0xFFCCCCCC.toInt() else 0xFF4A4A4A.toInt())
        Icons.draw(c, "down", 25f, yb, 26f, if (canDown) 0xFFCCCCCC.toInt() else 0xFF4A4A4A.toInt())
        if (pageLabel != null) text(c, pageLabel, 25f, (ya + yb) / 2 + 4f, 9f, 0xFF808080.toInt(), false, Paint.Align.CENTER)
        val b = hit(0f, H - 60f, 50f, H) { app.pop() }
        Icons.draw(c, "back", 25f, H - 30f, 28f, if (b) 0xFF999999.toInt() else Color.WHITE)
    }

    fun header(c: Canvas, title: String) {
        fill(c, 52f, 0f, W, 28f, 0xFF2B2B2B.toInt())
        text(c, fit(title, 15f, W - 70f, true), 62f, 19f, 15f, Color.WHITE, true)
    }
}

class ListPane(app: MainActivity, private val title: String?, private val provider: () -> List<Row>) : SidePane(app) {
    private var page = 0

    override fun draw0(c: Canvas) {
        val rows = provider()
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        val top = if (title != null) 28f else 0f
        val per = maxOf(3, ((H - top) / 54f).toInt())
        val rh = (H - top) / per
        val pages = maxOf(1, (rows.size + per - 1) / per)
        if (page >= pages) page = pages - 1
        canUp = page > 0
        canDown = page < pages - 1
        onUp = { page--; invalidate() }
        onDown = { page++; invalidate() }
        for (i in 0 until per) {
            val k = page * per + i
            if (k >= rows.size) break
            val r = rows[k]
            val y = top + i * rh
            val t = r.tap
            val pressed = if (t != null) hit(54f, y, W, y + rh) { t(); invalidate() } else false
            if (pressed) fill(c, 52f, y, W, y + rh, 0xFFD3E2F2.toInt())
            fill(c, 52f, y + rh - 1f, W, y + rh, 0xFFC9C9C6.toInt())
            var x = 64f
            val icon = r.icon
            val img = r.img
            if (icon != null) {
                Icons.draw(c, icon, 84f, y + rh / 2, 34f, 0xFF333333.toInt())
                x = 112f
            } else if (img != null) {
                img.setBounds(62, (y + rh / 2 - 18).toInt(), 98, (y + rh / 2 + 18).toInt())
                img.draw(c)
                x = 108f
            }
            val v = r.value
            val vw = if (v != null) minOf(150f, (W - x) * 0.4f) else 0f
            // Non-tappable rows (e.g. "No saved places yet") are muted so it's clear at a glance they're informational, not inert buttons.
            val ink = if (t != null) 0xFF1E1E1E.toInt() else 0xFF9A9A9A.toInt()
            val sub = r.sub
            if (sub != null) {
                text(c, fit(r.title, 17f, W - x - vw - 10f), x, y + rh / 2 - 3f, 17f, ink)
                text(c, fit(sub, 11f, W - x - vw - 10f), x, y + rh / 2 + 14f, 11f, 0xFF707070.toInt())
            } else {
                text(c, fit(r.title, 17f, W - x - vw - 10f), x, y + rh / 2 + 6f, 17f, ink)
            }
            if (v != null) text(c, fit(v, 15f, vw), W - 10f, y + rh / 2 + 6f, 15f, 0xFF4A6A8A.toInt(), false, Paint.Align.RIGHT)
        }
        if (title != null) header(c, title)
        sidebar(c, if (pages > 1) "${page + 1}/$pages" else null)
    }
}
