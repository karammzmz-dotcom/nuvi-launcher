package com.nuvi.launcher

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper

object Gps {
    class Sat(val id: Int, val snr: Float, val used: Boolean)

    var loc: Location? = null
    var satList: List<Sat> = emptyList()
    var satsUsed = 0
    val listeners = mutableListOf<(Location) -> Unit>()
    val satListeners = mutableListOf<() -> Unit>()

    private var started = false
    private lateinit var ctx: Context
    private lateinit var lm: LocationManager

    fun init(c: Context) {
        ctx = c.applicationContext
        lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }

    fun hasFix(): Boolean {
        val l = loc ?: return false
        return System.currentTimeMillis() - l.time < 20000
    }

    private val ll = object : LocationListener {
        override fun onLocationChanged(l: Location) {
            val cur = loc
            val better = cur == null || l.provider == LocationManager.GPS_PROVIDER ||
                cur.provider != LocationManager.GPS_PROVIDER || l.time - cur.time > 10000
            if (better) {
                loc = l
                listeners.toList().forEach { it(l) }
            }
        }
        override fun onProviderEnabled(p: String) {}
        override fun onProviderDisabled(p: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
    }

    private val gcb = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(s: GnssStatus) {
            val l = ArrayList<Sat>()
            for (i in 0 until s.satelliteCount) l.add(Sat(s.getSvid(i), s.getCn0DbHz(i), s.usedInFix(i)))
            satList = l
            satsUsed = l.count { it.used }
            satListeners.toList().forEach { it() }
        }
    }

    @SuppressLint("MissingPermission")
    fun start() {
        if (started) return
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            for (prov in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                if (lm.allProviders.contains(prov)) lm.requestLocationUpdates(prov, 1000L, 0f, ll, Looper.getMainLooper())
            }
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            lm.registerGnssStatusCallback(gcb, Handler(Looper.getMainLooper()))
            started = true
        } catch (e: SecurityException) {
        } catch (e: IllegalArgumentException) {
        }
    }

    fun stop() {
        if (!started) return
        try { lm.removeUpdates(ll); lm.unregisterGnssStatusCallback(gcb) } catch (e: Exception) { }
        started = false
    }
}
