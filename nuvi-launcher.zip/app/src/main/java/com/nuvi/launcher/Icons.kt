package com.nuvi.launcher

import android.graphics.*
import kotlin.math.cos
import kotlin.math.sin

object Icons {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val BLUE = 0xFF2F7FC8.toInt()
    private val WHITE = 0xFFFFFFFF.toInt()

    private fun fillP(color: Int): Paint { p.reset(); p.isAntiAlias = true; p.color = color; return p }

    private fun strokeP(color: Int, w: Float): Paint {
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.color = color
        p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        return p
    }

    private fun tile(c: Canvas, h: Float) {
        p.reset(); p.isAntiAlias = true; p.color = 0x33000000
        c.drawOval(RectF(-h * .5f, h * .8f, h * .5f, h * 1.0f), p)
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(0f, -h, 0f, h, 0xFF5AA8F0.toInt(), 0xFF1F66B0.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(-h * .75f, -h * .85f, h * .75f, h * .55f), h * .25f, h * .25f, p)
        val a = Path()
        a.moveTo(-h * .22f, h * .5f); a.lineTo(h * .22f, h * .5f); a.lineTo(0f, h * .92f); a.close()
        c.drawPath(a, p)
        p.reset(); p.isAntiAlias = true; p.color = 0x26FFFFFF
        c.drawRoundRect(RectF(-h * .68f, -h * .8f, h * .68f, -h * .2f), h * .22f, h * .22f, p)
    }

    private fun glyphText(c: Canvas, s: String, h: Float) {
        p.reset(); p.isAntiAlias = true; p.color = WHITE; p.textSize = h * 1.0f
        p.textAlign = Paint.Align.CENTER; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(s, 0f, h * .2f, p)
    }

    fun draw(c: Canvas, t: String, cx: Float, cy: Float, s: Float, fg: Int) {
        c.save()
        c.translate(cx, cy)
        val h = s / 2
        val sw = s * 0.12f
        when (t) {
            "menu" -> for (i in -1..1) c.drawLine(-h * .8f, i * h * .5f, h * .8f, i * h * .5f, strokeP(fg, sw))
            "up", "down" -> {
                val d = if (t == "up") 1f else -1f
                val a = Path()
                a.moveTo(-h * .8f, d * h * .5f); a.lineTo(0f, -d * h * .5f); a.lineTo(h * .8f, d * h * .5f); a.close()
                c.drawPath(a, fillP(fg))
            }
            "back" -> {
                val a = Path()
                a.moveTo(-h * .3f, -h * .45f); a.lineTo(h * .35f, -h * .45f)
                a.quadTo(h * .85f, -h * .45f, h * .85f, h * .05f)
                a.quadTo(h * .85f, h * .55f, h * .35f, h * .55f)
                a.lineTo(-h * .3f, h * .55f)
                c.drawPath(a, strokeP(fg, sw * 1.2f))
                val hd = Path()
                hd.moveTo(-h * .3f, h * .15f); hd.lineTo(-h * .85f, h * .55f); hd.lineTo(-h * .3f, h * .95f); hd.close()
                c.drawPath(hd, fillP(fg))
            }
            "plus" -> {
                c.drawLine(-h * .7f, 0f, h * .7f, 0f, strokeP(fg, sw * 1.4f))
                c.drawLine(0f, -h * .7f, 0f, h * .7f, strokeP(fg, sw * 1.4f))
            }
            "minus" -> c.drawLine(-h * .7f, 0f, h * .7f, 0f, strokeP(fg, sw * 1.4f))
            "search" -> {
                c.drawCircle(-h * .15f, -h * .15f, h * .55f, strokeP(fg, sw * 1.2f))
                c.drawLine(h * .25f, h * .25f, h * .8f, h * .8f, strokeP(fg, sw * 1.6f))
            }
            "heart" -> {
                c.drawCircle(-h * .3f, -h * .2f, h * .42f, fillP(fg))
                c.drawCircle(h * .3f, -h * .2f, h * .42f, fillP(fg))
                val a = Path()
                a.moveTo(-h * .68f, 0f); a.lineTo(h * .68f, 0f); a.lineTo(0f, h * .8f); a.close()
                c.drawPath(a, fillP(fg))
            }
            "clock" -> {
                c.drawCircle(0f, 0f, h * .85f, fillP(fg))
                c.drawLine(0f, 0f, 0f, -h * .5f, strokeP(0xFFF4F4F2.toInt(), sw))
                c.drawLine(0f, 0f, h * .35f, h * .1f, strokeP(0xFFF4F4F2.toInt(), sw))
            }
            "bubble" -> {
                c.drawRoundRect(RectF(-h * .8f, -h * .8f, h * .8f, h * .35f), h * .15f, h * .15f, fillP(fg))
                val a = Path()
                a.moveTo(-h * .25f, h * .3f); a.lineTo(h * .25f, h * .3f); a.lineTo(0f, h * .8f); a.close()
                c.drawPath(a, fillP(fg))
            }
            "stop" -> {
                c.drawCircle(0f, 0f, h * .85f, fillP(fg))
                c.drawLine(-h * .35f, -h * .35f, h * .35f, h * .35f, strokeP(0xFFEAF0F6.toInt(), sw * 1.3f))
                c.drawLine(h * .35f, -h * .35f, -h * .35f, h * .35f, strokeP(0xFFEAF0F6.toInt(), sw * 1.3f))
            }
            "apps" -> {
                c.drawRoundRect(RectF(-h * .85f, -h * .05f, h * .85f, h * .8f), h * .12f, h * .12f, fillP(fg))
                c.drawRect(RectF(-h * .62f, -h * .42f, h * .62f, -h * .17f), fillP(fg))
                c.drawArc(RectF(-h * .3f, -h * .8f, h * .3f, -h * .2f), 180f, 180f, false, strokeP(fg, sw * .8f))
            }
            "volume" -> {
                val a = Path()
                a.moveTo(-h * .9f, -h * .3f); a.lineTo(-h * .45f, -h * .3f); a.lineTo(0f, -h * .75f)
                a.lineTo(0f, h * .75f); a.lineTo(-h * .45f, h * .3f); a.lineTo(-h * .9f, h * .3f); a.close()
                c.drawPath(a, fillP(fg))
                c.drawArc(RectF(-h * .3f, -h * .4f, h * .35f, h * .4f), -50f, 100f, false, strokeP(fg, sw))
                c.drawArc(RectF(-h * .3f, -h * .75f, h * .85f, h * .75f), -50f, 100f, false, strokeP(fg, sw))
            }
            "tools" -> {
                c.save(); c.rotate(45f)
                c.drawRoundRect(RectF(-h * .13f, -h * .3f, h * .13f, h * .95f), h * .1f, h * .1f, fillP(fg))
                val w = Path()
                w.fillType = Path.FillType.EVEN_ODD
                w.addCircle(0f, -h * .55f, h * .38f, Path.Direction.CW)
                w.addRect(-h * .13f, -h * .9f, h * .13f, -h * .55f, Path.Direction.CW)
                c.drawPath(w, fillP(fg))
                c.restore()
                c.save(); c.rotate(-45f)
                c.drawRoundRect(RectF(-h * .17f, h * .15f, h * .17f, h * .95f), h * .12f, h * .12f, fillP(fg))
                c.drawLine(0f, h * .15f, 0f, -h * .8f, strokeP(fg, sw * .8f))
                c.restore()
            }
            "shift" -> {
                val a = Path()
                a.moveTo(0f, -h * .75f); a.lineTo(h * .75f, h * .05f); a.lineTo(h * .33f, h * .05f); a.lineTo(h * .33f, h * .75f)
                a.lineTo(-h * .33f, h * .75f); a.lineTo(-h * .33f, h * .05f); a.lineTo(-h * .75f, h * .05f); a.close()
                c.drawPath(a, strokeP(fg, sw))
            }
            "bksp" -> {
                val a = Path()
                a.moveTo(-h * .9f, 0f); a.lineTo(-h * .4f, -h * .6f); a.lineTo(h * .9f, -h * .6f)
                a.lineTo(h * .9f, h * .6f); a.lineTo(-h * .4f, h * .6f); a.close()
                c.drawPath(a, fillP(fg))
                c.drawLine(-h * .05f, -h * .25f, h * .5f, h * .25f, strokeP(0xFF222222.toInt(), sw))
                c.drawLine(h * .5f, -h * .25f, -h * .05f, h * .25f, strokeP(0xFF222222.toInt(), sw))
            }
            "space" -> {
                val a = Path()
                a.moveTo(-h * .8f, -h * .1f); a.lineTo(-h * .8f, h * .3f); a.lineTo(h * .8f, h * .3f); a.lineTo(h * .8f, -h * .1f)
                c.drawPath(a, strokeP(fg, sw))
            }
            "globe" -> {
                c.drawCircle(0f, 0f, h * .8f, strokeP(fg, sw * .8f))
                c.drawOval(RectF(-h * .35f, -h * .8f, h * .35f, h * .8f), strokeP(fg, sw * .6f))
                c.drawLine(-h * .8f, 0f, h * .8f, 0f, strokeP(fg, sw * .6f))
            }
            "mapPin" -> {
                c.drawCircle(0f, -h * .3f, h * .6f, fillP(BLUE))
                val a = Path()
                a.moveTo(-h * .5f, -h * .05f); a.lineTo(h * .5f, -h * .05f); a.lineTo(0f, h * .9f); a.close()
                c.drawPath(a, fillP(BLUE))
                c.drawCircle(0f, -h * .3f, h * .22f, fillP(WHITE))
            }
            "house" -> {
                p.reset(); p.isAntiAlias = true; p.color = 0x33000000
                c.drawOval(RectF(-h * .9f, h * .72f, h * .9f, h * .95f), p)
                c.drawRect(RectF(h * .35f, -h * .8f, h * .6f, -h * .3f), fillP(0xFF8E2B20.toInt()))
                p.reset(); p.isAntiAlias = true
                p.shader = LinearGradient(0f, -h * .05f, 0f, h * .8f, 0xFF63A8EE.toInt(), 0xFF3070B8.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(RectF(-h * .7f, -h * .05f, h * .7f, h * .8f), p)
                val a = Path()
                a.moveTo(-h * .98f, -h * .02f); a.lineTo(0f, -h * .92f); a.lineTo(h * .98f, -h * .02f); a.close()
                p.reset(); p.isAntiAlias = true
                p.shader = LinearGradient(0f, -h * .92f, 0f, 0f, 0xFFE0594A.toInt(), 0xFFA82F22.toInt(), Shader.TileMode.CLAMP)
                c.drawPath(a, p)
                c.drawRect(RectF(-h * .17f, h * .28f, h * .17f, h * .8f), fillP(0xFFB5362A.toInt()))
                c.drawRect(RectF(h * .3f, h * .08f, h * .56f, h * .34f), fillP(WHITE))
                c.drawRect(RectF(h * .3f, h * .08f, h * .56f, h * .34f), strokeP(0xFF2B5E9E.toInt(), sw * .4f))
            }
            "address" -> {
                c.drawRect(RectF(-h * .85f, -h * .6f, h * .55f, h * .3f), fillP(0xFFF5F5F0.toInt()))
                c.drawRect(RectF(-h * .85f, -h * .6f, h * .55f, h * .3f), strokeP(0xFF999999.toInt(), sw * .6f))
                c.drawLine(-h * .85f, -h * .6f, -h * .15f, -h * .1f, strokeP(0xFF999999.toInt(), sw * .6f))
                c.drawLine(h * .55f, -h * .6f, -h * .15f, -h * .1f, strokeP(0xFF999999.toInt(), sw * .6f))
                c.drawCircle(h * .3f, h * .2f, h * .4f, strokeP(0xFF666666.toInt(), sw))
                c.drawLine(h * .55f, h * .5f, h * .85f, h * .85f, strokeP(0xFF2F7FC8.toInt(), sw * 1.5f))
            }
            "restaurant", "fuel", "atm", "parking", "lodging", "hospital", "attraction", "shopping",
            "food", "cities", "coords", "intersection" -> {
                tile(c, h)
                c.translate(0f, -h * .15f)
                when (t) {
                    "restaurant" -> {
                        val w = strokeP(WHITE, sw * .75f)
                        for (x in floatArrayOf(-.42f, -.28f, -.14f)) c.drawLine(h * x, -h * .5f, h * x, -h * .12f, w)
                        c.drawArc(RectF(-h * .42f, -h * .3f, -h * .14f, h * .02f), 0f, 180f, false, w)
                        c.drawLine(-h * .28f, h * .02f, -h * .28f, h * .4f, strokeP(WHITE, sw * 1.1f))
                        c.drawRoundRect(RectF(h * .16f, -h * .52f, h * .36f, h * .04f), h * .1f, h * .1f, fillP(WHITE))
                        c.drawLine(h * .26f, h * .04f, h * .26f, h * .4f, strokeP(WHITE, sw * 1.1f))
                    }
                    "fuel" -> {
                        c.drawRoundRect(RectF(-h * .38f, -h * .52f, h * .08f, h * .32f), h * .07f, h * .07f, fillP(WHITE))
                        c.drawRect(RectF(-h * .28f, -h * .42f, -h * .02f, -h * .12f), fillP(0xFF3A82CC.toInt()))
                        c.drawLine(-h * .48f, h * .32f, h * .18f, h * .32f, strokeP(WHITE, sw))
                        val a = Path()
                        a.moveTo(h * .08f, -h * .3f); a.lineTo(h * .32f, -h * .3f); a.lineTo(h * .32f, h * .12f)
                        c.drawPath(a, strokeP(WHITE, sw * .8f))
                        c.drawCircle(h * .32f, h * .2f, h * .09f, fillP(WHITE))
                    }
                    "atm" -> glyphText(c, "$", h)
                    "parking" -> glyphText(c, "P", h)
                    "lodging" -> {
                        c.drawRect(RectF(-h * .5f, -h * .1f, h * .5f, h * .2f), fillP(WHITE))
                        c.drawRect(RectF(-h * .5f, -h * .45f, -h * .38f, h * .2f), fillP(WHITE))
                        c.drawCircle(-h * .2f, -h * .22f, h * .14f, fillP(WHITE))
                    }
                    "hospital" -> {
                        c.drawLine(-h * .4f, -h * .1f, h * .4f, -h * .1f, strokeP(WHITE, sw * 1.7f))
                        c.drawLine(0f, -h * .5f, 0f, h * .3f, strokeP(WHITE, sw * 1.7f))
                    }
                    "attraction" -> {
                        val a = Path()
                        for (i in 0 until 10) {
                            val ang = Math.toRadians(-90.0 + i * 36.0)
                            val r = if (i % 2 == 0) h * .55f else h * .22f
                            val x = (cos(ang) * r).toFloat()
                            val y = (sin(ang) * r).toFloat()
                            if (i == 0) a.moveTo(x, y) else a.lineTo(x, y)
                        }
                        a.close()
                        c.drawPath(a, fillP(WHITE))
                    }
                    "shopping" -> {
                        val a = Path()
                        a.moveTo(-h * .4f, -h * .25f); a.lineTo(h * .4f, -h * .25f); a.lineTo(h * .5f, h * .35f); a.lineTo(-h * .5f, h * .35f); a.close()
                        c.drawPath(a, fillP(WHITE))
                        c.drawArc(RectF(-h * .2f, -h * .6f, h * .2f, -h * .05f), 180f, 180f, false, strokeP(WHITE, sw * .7f))
                    }
                    "food" -> {
                        c.drawArc(RectF(-h * .45f, -h * .5f, h * .45f, h * .1f), 180f, 180f, true, fillP(WHITE))
                        c.drawLine(-h * .45f, h * .2f, h * .45f, h * .2f, strokeP(WHITE, sw * .8f))
                        c.drawRect(RectF(-h * .45f, h * .3f, h * .45f, h * .42f), fillP(WHITE))
                    }
                    "cities" -> {
                        c.drawRect(RectF(-h * .5f, -h * .1f, -h * .2f, h * .35f), fillP(WHITE))
                        c.drawRect(RectF(-h * .15f, -h * .5f, h * .15f, h * .35f), fillP(WHITE))
                        c.drawRect(RectF(h * .2f, -h * .25f, h * .5f, h * .35f), fillP(WHITE))
                    }
                    "coords" -> {
                        c.drawCircle(0f, 0f, h * .35f, strokeP(WHITE, sw * .8f))
                        c.drawLine(-h * .55f, 0f, h * .55f, 0f, strokeP(WHITE, sw * .8f))
                        c.drawLine(0f, -h * .55f, 0f, h * .55f, strokeP(WHITE, sw * .8f))
                    }
                    "intersection" -> {
                        c.drawLine(-h * .45f, -h * .5f, h * .45f, h * .3f, strokeP(WHITE, sw * 1.4f))
                        c.drawLine(h * .45f, -h * .5f, -h * .45f, h * .3f, strokeP(WHITE, sw * 1.4f))
                    }
                }
            }
            else -> c.drawCircle(0f, 0f, h * .4f, fillP(fg))
        }
        c.restore()
    }

    fun bitmap(t: String, px: Int): Bitmap {
        val b = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        draw(Canvas(b), t, px / 2f, px / 2f, px * 0.9f, WHITE)
        return b
    }
}
