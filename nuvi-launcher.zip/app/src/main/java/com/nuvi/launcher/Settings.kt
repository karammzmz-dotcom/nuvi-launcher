package com.nuvi.launcher

import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.BitmapDrawable
import android.provider.Settings

private fun onOff(b: Boolean) = if (b) "On" else "Off"

fun settingsRoot(app: MainActivity): ListPane = ListPane(app, "Settings") {
    val l = ArrayList<Row>()
    l.add(Row("Display", tap = { app.push(displaySettings(app)) }))
    l.add(Row("Brightness", value = if (Prefs.brightness <= 0) "System" else "${Prefs.brightness}%", tap = { app.openBrightness() }))
    l.add(Row("Language", tap = { app.push(languageSettings(app)) }))
    l.add(Row("Units", value = if (Prefs.miles) "Miles" else "Kilometers", tap = { app.push(unitsSettings(app)) }))
    l.add(Row("Time", value = if (Prefs.h24) "24-hour" else "12-hour", tap = { app.push(timeSettings(app)) }))
    l.add(Row("Map Settings", tap = { app.push(mapSettings(app)) }))
    l.add(Row("Navigation Settings", tap = { app.push(navSettings(app)) }))
    val bt = (app.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    if (bt != null) {
        val on = try { bt.isEnabled } catch (e: SecurityException) { false }
        l.add(Row("Bluetooth", value = onOff(on), tap = {
            try { app.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { app.toast("Bluetooth settings not available") }
        }))
    }
    l.add(Row("GPS Information", tap = { app.push(GpsPane(app)) }))
    l.add(Row("About", tap = { app.push(aboutPane(app)) }))
    l
}

private fun displaySettings(app: MainActivity) = ListPane(app, "Display") {
    listOf(
        Row("Orientation", value = listOf("Auto", "Landscape", "Portrait")[Prefs.orientation], tap = {
            Prefs.orientation = (Prefs.orientation + 1) % 3; app.applyPrefs()
        }),
        Row("Launcher Mode (hide Android bars)", value = onOff(Prefs.immersive), tap = {
            Prefs.immersive = !Prefs.immersive; app.applyPrefs()
        }),
        Row("Key Tones", value = onOff(Prefs.keyTones), tap = { Prefs.keyTones = !Prefs.keyTones }),
        Row("Touch Feedback", value = onOff(Prefs.haptics), tap = { Prefs.haptics = !Prefs.haptics }),
        Row("Brightness", value = if (Prefs.brightness <= 0) "System" else "${Prefs.brightness}%", tap = { app.openBrightness() })
    )
}

private fun languageSettings(app: MainActivity) = ListPane(app, "Language") {
    listOf(
        Row("Keyboard Language", value = if (Prefs.kbArabic) "العربية" else "English", tap = { Prefs.kbArabic = !Prefs.kbArabic }),
        Row("Voice Language", value = if (Prefs.voiceUk) "English (UK)" else "English (US)", tap = { Prefs.voiceUk = !Prefs.voiceUk })
    )
}

private fun unitsSettings(app: MainActivity) = ListPane(app, "Units") {
    listOf(
        Row("Distance Units", value = if (Prefs.miles) "Miles" else "Kilometers", tap = { Prefs.miles = !Prefs.miles })
    )
}

private fun timeSettings(app: MainActivity) = ListPane(app, "Time") {
    listOf(
        Row("Time Format", value = if (Prefs.h24) "24-hour" else "12-hour", tap = { Prefs.h24 = !Prefs.h24 })
    )
}

private fun mapSettings(app: MainActivity) = ListPane(app, "Map Settings") {
    listOf(
        Row("Map View", value = if (Prefs.northUp) "North Up" else "Track Up", tap = { Prefs.northUp = !Prefs.northUp }),
        Row("Map Colors", value = listOf("Auto", "Day", "Night")[Prefs.colorMode], tap = { Prefs.colorMode = (Prefs.colorMode + 1) % 3 }),
        Row("Vehicle", value = if (Vehicle.has()) Prefs.vehicleName else "Default", tap = { app.push(vehicleSettings(app)) })
    )
}

private fun vehicleSettings(app: MainActivity) = ListPane(app, "Vehicle") {
    val l = ArrayList<Row>()
    val fr = Vehicle.frame(0f)
    if (fr != null) l.add(Row("Current Vehicle", sub = Prefs.vehicleName, img = BitmapDrawable(app.resources, fr)))
    else l.add(Row("Current Vehicle", sub = "Default car", icon = "mapPin"))
    l.add(Row("Import .srf File", icon = "plus", tap = { app.pickVehicleFile() }))
    if (Vehicle.has()) {
        if (Vehicle.frames.size > 1) {
            l.add(Row("View", value = if (Prefs.vehicleView == 0) "3D" else "Overhead", tap = { Prefs.vehicleView = if (Prefs.vehicleView == 0) 1 else 0 }))
        }
        l.add(Row("Rotation Direction", value = if (Prefs.vehicleCw) "Clockwise" else "Counter-clockwise", tap = { Prefs.vehicleCw = !Prefs.vehicleCw }))
        l.add(Row("Size", value = listOf("Small", "Medium", "Large")[Prefs.vehicleScale], tap = { Prefs.vehicleScale = (Prefs.vehicleScale + 1) % 3 }))
        l.add(Row("Remove Custom Vehicle", icon = "stop", tap = { Vehicle.reset(app) }))
    }
    l
}

private fun navSettings(app: MainActivity) = ListPane(app, "Navigation Settings") {
    listOf(
        Row("Avoid Highways", value = onOff(Prefs.avoidHw), tap = { Prefs.avoidHw = !Prefs.avoidHw }),
        Row("Avoid Toll Roads", value = onOff(Prefs.avoidToll), tap = { Prefs.avoidToll = !Prefs.avoidToll }),
        Row("Voice Guidance", value = onOff(Prefs.voice), tap = { Prefs.voice = !Prefs.voice }),
        Row("Home Location", value = if (Prefs.home != null) "Set" else "Not set", tap = { app.setHomeFlow() })
    )
}

private fun aboutPane(app: MainActivity) = ListPane(app, "About") {
    listOf(
        Row("nüvi Launcher 1.0", sub = "Garmin nüvi 55 style home app"),
        Row("Map data", sub = "© OpenStreetMap contributors"),
        Row("Routing / Search", sub = "OSRM demo server, Nominatim, Overpass"),
        Row("Set as Default Home App", icon = "house", tap = {
            try { app.startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) } catch (e: Exception) { app.toast("Open Android Settings > Apps > Default apps") }
        })
    )
}
