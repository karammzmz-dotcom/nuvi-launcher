package com.nuvi.launcher

import android.content.Intent
import android.content.IntentFilter
import android.graphics.*
import android.os.BatteryManager
import kotlin.math.min

// ---------------------------------------------------------------- Home screen
class HomePane(private val app: MainActivity) : Pane(app) {
    init { tickMs = 5000 }

    private val ink = 0xFF1A1A1A.toInt()

    override fun draw0(c: Canvas) {
        p.reset()
        p.shader = LinearGradient(0f, 0f, 0f, H, 0xFFD6E0E9.toInt(), 0xFFB9CAD9.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W, H, p)
        // faint world-map watermark blobs
        p.reset(); p.isAntiAlias = true; p.color = 0x14FFFFFF
        c.drawOval(RectF(W * .05f, H * .2f, W * .3f, H * .45f), p)
        c.drawOval(RectF(W * .55f, H * .12f, W * .9f, H * .4f), p)

        val land = W > H
        if (land) {
            hit(0f, 26f, W / 2, 196f) { app.openWhere() }
            hit(W / 2, 26f, W, 196f) { app.openMap() }
            magnifier(c, W * 0.25f - 24f, 88f, 38f)
            text(c, "Where To?", W * 0.25f, 178f, 30f, ink, false, Paint.Align.CENTER)
            pushpin(c, W * 0.75f, 36f)
            text(c, "View Map", W * 0.75f, 178f, 30f, ink, false, Paint.Align.CENTER)
            val xs = floatArrayOf(.13f, .37f, .63f, .87f)
            items(c, xs.map { it * W }, listOf(216f, 216f, 216f, 216f))
        } else {
            val cx = (W - 70f) / 2
            hit(0f, 26f, W - 70f, H * 0.47f) { app.openWhere() }
            hit(0f, H * 0.47f, W - 70f, H) { app.openMap() }
            magnifier(c, cx - 16f, H * 0.2f, 34f)
            text(c, "Where To?", cx, H * 0.4f, 26f, ink, false, Paint.Align.CENTER)
            pushpin(c, cx, H * 0.5f)
            text(c, "View Map", cx, H * 0.9f, 26f, ink, false, Paint.Align.CENTER)
            val ys = listOf(H * .16f, H * .36f, H * .56f, H * .76f)
            items(c, listOf(W - 36f, W - 36f, W - 36f, W - 36f), ys)
        }
        statusBar(c)
    }

    private fun items(c: Canvas, xs: List<Float>, ys: List<Float>) {
        val active = Nav.dest != null
        data class It(val icon: String, val label: String, val on: Boolean, val f: () -> Unit)
        val list = listOf(
            It("stop", "Stop", active) { Nav.stop(); invalidate() },
            It("apps", "Apps", true) { app.openApps() },
            It("volume", "Volume", true) { app.openVolume() },
            It("tools", "Settings", true) { app.openSettings() }
        )
        for (i in list.indices) {
            val it = list[i]
            val x = xs[i]
            val y = ys[i]
            val col = if (it.on) 0xFF1A1A1A.toInt() else 0xFF9FB2C6.toInt()
            if (it.on) hit(x - 44f, y - 24f, x + 44f, y + 40f, it.f)
            Icons.draw(c, it.icon, x, y, 30f, col)
            text(c, it.label, x, y + 36f, 13f, col, false, Paint.Align.CENTER)
        }
    }

    private fun statusBar(c: Canvas) {
        fill(c, 0f, 0f, W, 24f, Color.BLACK)
        fill(c, 0f, 24f, W, 25.5f, 0xFFC9A36A.toInt())
        val bars = if (!Gps.hasFix()) 0 else min(5, 1 + Gps.satsUsed / 3)
        for (i in 0 until 5) fill(c, 8f + i * 5f, 19f - (3 + i * 2.5f), 11f + i * 5f, 19f, if (i < bars) Color.WHITE else 0xFF555555.toInt())
        val (tm, ap) = Fmt.clock(System.currentTimeMillis())
        text(c, tm, W / 2, 19f, 16f, Color.WHITE, true, Paint.Align.CENTER)
        val tw = p.measureText(tm)
        if (ap.isNotEmpty()) {
            text(c, ap.substring(0, 1), W / 2 + tw / 2 + 2f, 11f, 7.5f, Color.WHITE, true)
            text(c, ap.substring(1, 2), W / 2 + tw / 2 + 2f, 20f, 7.5f, Color.WHITE, true)
        }
        // battery
        val bi = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = if (bi != null) bi.getIntExtra(BatteryManager.EXTRA_LEVEL, 50) * 100 / maxOf(1, bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100)) else 50
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 1.2f; p.color = Color.WHITE
        c.drawRect(W - 32f, 7f, W - 10f, 17f, p)
        fill(c, W - 10f, 10f, W - 8f, 14f, Color.WHITE)
        fill(c, W - 30.5f, 8.5f, W - 30.5f + 19f * lvl / 100f, 15.5f, if (lvl > 20) 0xFF3FA34D.toInt() else 0xFFD04B3A.toInt())
    }

    private fun magnifier(c: Canvas, cx: Float, cy: Float, r: Float) {
        // handle
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.24f; p.strokeCap = Paint.Cap.ROUND
        p.shader = LinearGradient(cx, cy, cx + r * 2.2f, cy + r, 0xFF8EC3F0.toInt(), 0xFF2F7FC8.toInt(), Shader.TileMode.CLAMP)
        c.drawLine(cx + r * 0.85f, cy + r * 0.45f, cx + r * 2.1f, cy + r * 0.95f, p)
        // shadow
        p.reset(); p.isAntiAlias = true; p.color = 0x22000000
        c.drawOval(RectF(cx - r, cy + r * 1.0f, cx + r * 1.8f, cy + r * 1.3f), p)
        // ring
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(cx - r, cy - r, cx + r, cy + r, 0xFFF4F6F8.toInt(), 0xFF7E8A96.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        // glass
        p.reset(); p.isAntiAlias = true
        p.shader = RadialGradient(cx - r * .3f, cy - r * .35f, r, 0xFFE4EAF0.toInt(), 0xFF9CA9B6.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.84f, p)
    }

    private fun pushpin(c: Canvas, cx: Float, top: Float) {
        // folded map
        val m = Path()
        m.moveTo(cx - 62f, top + 112f); m.lineTo(cx - 28f, top + 82f); m.lineTo(cx + 62f, top + 84f); m.lineTo(cx + 42f, top + 114f); m.close()
        p.reset(); p.isAntiAlias = true; p.color = 0xFFE9EDF0.toInt(); c.drawPath(m, p)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0xFF8C98A4.toInt(); c.drawPath(m, p)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xFFD6483A.toInt()
        c.drawLine(cx - 40f, top + 105f, cx + 30f, top + 92f, p)
        p.color = 0xFFE9A23B.toInt(); c.drawLine(cx - 30f, top + 108f, cx + 40f, top + 98f, p)
        fill(c, cx + 18f, top + 86f, cx + 34f, top + 92f, 0xFF6BBF6A.toInt())
        // needle
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0xFF98A4B0.toInt()
        c.drawLine(cx, top + 60f, cx, top + 96f, p)
        // pin body
        p.reset(); p.isAntiAlias = true
        p.shader = LinearGradient(cx - 10f, 0f, cx + 10f, 0f, 0xFFA8D6F6.toInt(), 0xFF3B86C8.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(cx - 9f, top + 12f, cx + 9f, top + 56f), 5f, 5f, p)
        c.drawRoundRect(RectF(cx - 24f, top + 46f, cx + 24f, top + 62f), 8f, 8f, p)
        c.drawRoundRect(RectF(cx - 16f, top, cx + 16f, top + 18f), 8f, 8f, p)
    }
}

// ---------------------------------------------------------------- Where To?
class WherePane(app: MainActivity) : SidePane(app) {
    private var page = 0

    private class Cell(val label: String, val icon: String, val f: () -> Unit)

    private val cells = listOf(
        Cell("Go Home", "house") { app.goHomePlace() },
        Cell("Address", "address") { app.openAddress(null) },
        Cell("Restaurants", "restaurant") { app.searchCategory(Cats.byName("Restaurants")) },
        Cell("Gas Stations", "fuel") { app.searchCategory(Cats.byName("Fuel")) },
        Cell("Shopping", "shopping") { app.searchCategory(Cats.byName("Shopping")) },
        Cell("Parking", "parking") { app.searchCategory(Cats.byName("Parking")) },
        Cell("Lodging", "lodging") { app.searchCategory(Cats.byName("Lodging")) },
        Cell("Hospitals", "hospital") { app.searchCategory(Cats.byName("Hospitals")) },
        Cell("ATMs", "atm") { app.searchCategory(Cats.byName("ATMs")) },
        Cell("Cities", "cities") { app.openCities() },
        Cell("Coordinates", "coords") { app.openCoords() },
        Cell("Intersections", "intersection") { app.openIntersections() }
    )

    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        // search field
        val sp = hit(58f, 6f, W - 142f, 42f) { app.openSearch() }
        box(c, 58f, 6f, W - 142f, 42f, if (sp) 0xFFE0E8F0.toInt() else Color.WHITE, if (sp) 0xFFE0E8F0.toInt() else 0xFFF4F4F4.toInt(), 0xFFB0B0B0.toInt())
        Icons.draw(c, "search", 76f, 24f, 20f, 0xFF777777.toInt())
        text(c, "Enter Search", 92f, 31f, 18f, 0xFF909090.toInt())
        // searching near
        hit(W - 136f, 6f, W - 4f, 42f) { app.toggleNear(); invalidate() }
        fill(c, W - 136f, 6f, W - 4f, 42f, 0xFF1E1E1E.toInt())
        text(c, "Searching near:", W - 70f, 19f, 9f, Color.WHITE, false, Paint.Align.CENTER)
        text(c, fit(app.nearLabel(), 12f, 124f, true), W - 70f, 34f, 12f, Color.WHITE, true, Paint.Align.CENTER)
        // right column
        val rx = W - 78f
        fill(c, rx, 46f, W, H, 0xFFE2E2E0.toInt())
        val ch = (H - 46f) / 3
        val rc = listOf(Triple("Categories", "bubble", { app.openCategories() }), Triple("Saved", "heart", { app.openSaved() }), Triple("Recent", "clock", { app.openRecents() }))
        for (i in rc.indices) {
            val y = 46f + i * ch
            val pr = hit(rx, y, W, y + ch) { rc[i].third() }
            if (pr) fill(c, rx, y, W, y + ch, 0xFFC8D8E8.toInt())
            Icons.draw(c, rc[i].second, rx + 39f, y + ch / 2 - 8f, 26f, 0xFF222222.toInt())
            text(c, rc[i].first, rx + 39f, y + ch / 2 + 22f, 12f, 0xFF222222.toInt(), false, Paint.Align.CENTER)
        }
        fill(c, rx - 1f, 46f, rx, H, 0xFFB8B8B6.toInt())
        // grid
        val gx0 = 56f
        val gw = rx - gx0
        val cols = if (gw >= 300f) 3 else 2
        val rows = if (H > 400f) 3 else 2
        val per = cols * rows
        val pages = (cells.size + per - 1) / per
        if (page >= pages) page = pages - 1
        canUp = page > 0
        canDown = page < pages - 1
        onUp = { page--; invalidate() }
        onDown = { page++; invalidate() }
        val cw = gw / cols
        val chh = (H - 46f) / rows
        for (i in 0 until per) {
            val k = page * per + i
            if (k >= cells.size) break
            val cell = cells[k]
            val x = gx0 + (i % cols) * cw
            val y = 46f + (i / cols) * chh
            val pr = hit(x, y, x + cw, y + chh) { cell.f() }
            if (pr) fill(c, x, y, x + cw, y + chh, 0xFFD3E2F2.toInt())
            Icons.draw(c, cell.icon, x + cw / 2, y + chh / 2 - 10f, 46f, 0xFF333333.toInt())
            text(c, fit(cell.label, 13f, cw - 4f), x + cw / 2, y + chh - 14f, 13f, 0xFF222222.toInt(), false, Paint.Align.CENTER)
        }
        sidebar(c)
    }
}

// ---------------------------------------------------------------- Keyboard
class KeyPane(
    private val app: MainActivity, private val hint: String, init0: String,
    private val record: Boolean = false, private val onSubmit: (String) -> Unit
) : Pane(app) {
    private var buf = init0
    private var shift = false
    private var sym = false

    private fun add(s: String) { buf += s; shift = false; invalidate() }

    private fun submit() {
        val q = buf.trim()
        if (q.isEmpty()) return
        if (record) Prefs.addQuery(q)
        onSubmit(q)
    }

    private fun key(
        c: Canvas, x: Float, y: Float, w: Float, h: Float, label: String?, icon: String?,
        top: Int = 0xFF3A3A3A.toInt(), bot: Int = 0xFF222222.toInt(), f: () -> Unit
    ) {
        val pr = hit(x, y, x + w, y + h, f)
        box(c, x + .5f, y + .5f, x + w - .5f, y + h - .5f, if (pr) 0xFF5A5A5A.toInt() else top, if (pr) 0xFF3C3C3C.toInt() else bot, 0xFF0A0A0A.toInt())
        if (label != null) text(c, label, x + w / 2, y + h / 2 + 7f, 20f, Color.WHITE, false, Paint.Align.CENTER)
        if (icon != null) Icons.draw(c, icon, x + w / 2, y + h / 2, 22f, Color.WHITE)
    }

    private fun row(c: Canvas, s: String, x0: Float, y: Float, kw: Float, rh: Float) {
        var x = x0
        val letters = !(Prefs.kbArabic && !sym)
        for (ch in s) {
            val lbl = if (shift && letters) ch.uppercaseChar().toString() else ch.toString()
            key(c, x, y, kw, rh, lbl, null) { add(lbl) }
            x += kw
        }
    }

    private fun suggestions(): List<String> {
        val q = buf.trim().lowercase()
        return Prefs.queries().filter { it.lowercase().contains(q) && it.lowercase() != q }.take(4)
    }

    override fun draw0(c: Canvas) {
        fill(c, 0f, 0f, W, H, 0xFF1C1C1C.toInt())
        val ar = Prefs.kbArabic && !sym
        val cols = if (ar) 11 else 10
        val kw = W / cols

        val hp = hit(4f, 6f, 38f, 42f) { app.toast(hint) }
        p.reset(); p.isAntiAlias = true; p.color = if (hp) 0xFF666666.toInt() else 0xFF2E2E2E.toInt()
        c.drawCircle(21f, 24f, 15f, p)
        text(c, "?", 21f, 31f, 20f, Color.WHITE, true, Paint.Align.CENTER)

        box(c, 42f, 6f, W - 4f, 42f, Color.WHITE, 0xFFF1F1F1.toInt(), 0xFF111111.toInt())
        val shown = fit(buf, 22f, W - 100f)
        text(c, shown, 48f, 33f, 22f, 0xFF111111.toInt())
        val tw = p.measureText(shown)
        fill(c, 50f + tw, 12f, 51.5f + tw, 37f, 0xFF2A5FB0.toInt())
        hit(W - 36f, 12f, W - 8f, 36f) { buf = ""; invalidate() }
        fill(c, W - 36f, 12f, W - 8f, 36f, 0xFF707070.toInt())
        c.save(); c.rotate(45f, W - 22f, 24f)
        Icons.draw(c, "plus", W - 22f, 24f, 16f, Color.WHITE)
        c.restore()

        // suggestions
        fill(c, 0f, 46f, W, 72f, 0xFF3A3F44.toInt())
        fill(c, 0f, 72f, W, 74f, 0xFFD9942B.toInt())
        val sug = suggestions()
        if (sug.isNotEmpty()) {
            val sw = W / sug.size
            for (i in sug.indices) {
                val s = sug[i]
                val pr = hit(i * sw, 46f, (i + 1) * sw, 72f) { buf = s; invalidate() }
                if (pr) fill(c, i * sw, 46f, (i + 1) * sw, 72f, 0xFF59616A.toInt())
                if (i > 0) fill(c, i * sw, 50f, i * sw + 1f, 68f, 0xFF6A727A.toInt())
                text(c, fit(s, 15f, sw - 8f), i * sw + sw / 2, 65f, 15f, Color.WHITE, false, Paint.Align.CENTER)
            }
        }

        val ky = 76f
        val rh = (H - ky) / 5f
        val r1 = if (sym) "@#$%&*()-+" else if (ar) "ضصثقفغعهخحج" else "qwertyuiop"
        val r2 = if (sym) "!?.,:;'\"/=" else if (ar) "شسيبلاتنمكط" else "asdfghjkl"
        val r3 = if (sym) (if (Prefs.kbArabic) "ئء_~<>[" else "_~<>[]|") else if (ar) "ظذدزرؤوىة" else "zxcvbnm"
        row(c, if (ar) "1234567890،" else "1234567890", 0f, ky, kw, rh)
        row(c, r1, (cols - r1.length) / 2f * kw, ky + rh, kw, rh)
        row(c, r2, (cols - r2.length) / 2f * kw, ky + 2 * rh, kw, rh)
        val y3 = ky + 3 * rh
        val slot = if (ar) kw else 1.5f * kw
        if (ar) key(c, 0f, y3, slot, rh, "ء", null) { add("ء") }
        else if (!sym) key(c, 0f, y3, slot, rh, null, "shift", if (shift) 0xFF6A6A6A.toInt() else 0xFF3A3A3A.toInt(), 0xFF222222.toInt()) { shift = !shift; invalidate() }
        row(c, r3, slot, y3, kw, rh)
        key(c, W - slot, y3, slot, rh, null, "bksp") { if (buf.isNotEmpty()) buf = buf.dropLast(1); invalidate() }

        val y4 = ky + 4 * rh
        var x = 0f
        val wb = 1.5f * kw
        key(c, x, y4, wb, rh, null, "back") { app.pop() }
        x += wb
        val ws = 2f * kw
        key(c, x, y4, ws, rh, if (sym) "abc" else "&?%", null) { sym = !sym; invalidate() }
        x += ws
        val wr = 2f * kw
        val wg = kw
        val wsp = W - x - wr - wg
        key(c, x, y4, wsp, rh, null, "space") { add(" ") }
        x += wsp
        key(c, x, y4, wg, rh, null, "globe", Color.BLACK, Color.BLACK) { Prefs.kbArabic = !Prefs.kbArabic; sym = false; invalidate() }
        x += wg
        key(c, x, y4, wr, rh, null, "search", 0xFF2E9A45.toInt(), 0xFF1E7A33.toInt()) { submit() }
    }
}

// ---------------------------------------------------------------- Place details
class DetailPane(app: MainActivity, private val pl: Place) : SidePane(app) {
    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        val ink = 0xFF1E1E1E.toInt()
        text(c, fit(pl.name, 22f, W - 70f, true), 62f, 34f, 22f, ink, true)
        // address wrapped on up to 3 lines
        var rest = pl.addr
        var y = 56f
        for (i in 0 until 3) {
            if (rest.isEmpty()) break
            p.reset(); p.textSize = 13f
            val n = p.breakText(rest, true, W - 72f, null)
            var cut = n
            if (n < rest.length) { val sp = rest.lastIndexOf(' ', n); if (sp > 0) cut = sp }
            text(c, rest.substring(0, cut).trim(), 62f, y, 13f, 0xFF555555.toInt())
            rest = rest.substring(cut).trim()
            y += 17f
        }
        val here = Gps.loc
        if (here != null) {
            text(c, Fmt.dist(hav(here.latitude, here.longitude, pl.lat, pl.lon)) + " away", 62f, H - 128f, 15f, 0xFF2F6AA8.toInt(), true)
        }
        text(c, Fmt.coord(pl.lat, pl.lon), 62f, H - 112f, 10f, 0xFF888888.toInt())

        // Go!
        val g = hit(58f, H - 106f, W - 6f, H - 58f) { app.startNav(pl) }
        box(c, 58f, H - 106f, W - 6f, H - 58f, if (g) 0xFF3FB35A.toInt() else 0xFF2E9A45.toInt(), if (g) 0xFF2A8A3E.toInt() else 0xFF1E7A33.toInt(), 0xFF145A24.toInt())
        text(c, "Go!", (58f + W - 6f) / 2, H - 70f, 28f, Color.WHITE, true, Paint.Align.CENTER)

        val bw = (W - 58f - 6f - 8f) / 3
        val by = H - 52f
        var bx = 58f
        val saved = Prefs.isSaved(pl)
        data class B(val icon: String, val label: String, val f: () -> Unit)
        val bs = listOf(
            B("heart", if (saved) "Saved" else "Save") { Prefs.toggleSaved(pl); invalidate() },
            B("house", "Set Home") { Prefs.home = pl; app.toast("Home location set"); invalidate() },
            B("mapPin", "Map") { app.showOnMap(pl) }
        )
        for (b in bs) {
            val pr = hit(bx, by, bx + bw, H - 6f, b.f)
            box(c, bx, by, bx + bw, H - 6f, if (pr) 0xFFD3E2F2.toInt() else 0xFFF8F8F8.toInt(), if (pr) 0xFFB8CCE0.toInt() else 0xFFD0D0D0.toInt(), 0xFF888888.toInt())
            Icons.draw(c, b.icon, bx + 22f, by + (H - 6f - by) / 2, 24f, if (b.icon == "heart" && saved) 0xFFD04B3A.toInt() else 0xFF333333.toInt())
            text(c, fit(b.label, 13f, bw - 44f), bx + 38f, by + (H - 6f - by) / 2 + 5f, 13f, ink)
            bx += bw + 4f
        }
        sidebar(c)
    }
}

// ---------------------------------------------------------------- Volume / Brightness
class LevelPane(
    app: MainActivity, private val title: String, private val get: () -> Int,
    private val set: (Int) -> Unit, private val extraLabel: String, private val extra: () -> Unit
) : SidePane(app) {
    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        header(c, title)
        val lvl = get().coerceIn(0, 100)
        val cx = (52f + W) / 2
        text(c, "$lvl%", cx, 100f, 40f, 0xFF1E1E1E.toInt(), true, Paint.Align.CENTER)
        val bw = (W - 52f - 130f) / 10f
        val x0 = 52f + 65f
        for (i in 0 until 10) {
            val x = x0 + i * bw
            val on = lvl >= (i + 1) * 10 - 4
            hit(x, 120f, x + bw, 170f) { set((i + 1) * 10); invalidate() }
            box(c, x + 1f, 120f, x + bw - 1f, 170f, if (on) 0xFF5A9AD8.toInt() else 0xFFE4E4E4.toInt(), if (on) 0xFF2F6AA8.toInt() else 0xFFC4C4C4.toInt(), 0xFF777777.toInt())
        }
        val m = hit(58f, 120f, x0 - 4f, 170f) { set((lvl - 10).coerceAtLeast(0)); invalidate() }
        Icons.draw(c, "minus", 52f + 32f, 145f, 28f, if (m) 0xFF2F6AA8.toInt() else 0xFF333333.toInt())
        val pl = hit(x0 + 10 * bw + 4f, 120f, W - 4f, 170f) { set((lvl + 10).coerceAtMost(100)); invalidate() }
        Icons.draw(c, "plus", W - 33f, 145f, 28f, if (pl) 0xFF2F6AA8.toInt() else 0xFF333333.toInt())
        val e = hit(cx - 80f, 190f, cx + 80f, 230f) { extra(); invalidate() }
        box(c, cx - 80f, 190f, cx + 80f, 230f, if (e) 0xFFD3E2F2.toInt() else 0xFFF8F8F8.toInt(), if (e) 0xFFB8CCE0.toInt() else 0xFFD0D0D0.toInt(), 0xFF888888.toInt())
        text(c, extraLabel, cx, 216f, 16f, 0xFF222222.toInt(), false, Paint.Align.CENTER)
        sidebar(c)
    }
}

// ---------------------------------------------------------------- GPS information
class GpsPane(app: MainActivity) : SidePane(app) {
    init { tickMs = 1000 }

    override fun draw0(c: Canvas) {
        fill(c, 52f, 0f, W, H, 0xFFF4F4F2.toInt())
        header(c, "GPS Information")
        val l = Gps.loc
        val sats = Gps.satList.sortedBy { it.id }.take(24)
        val x0 = 66f
        val cw = W - 78f
        val top = 40f
        val chH = 84f
        fill(c, x0 - 4f, top, x0 + cw + 4f, top + chH + 16f, 0xFFE6E6E4.toInt())
        val bw = cw / maxOf(sats.size, 12)
        for (i in sats.indices) {
            val s = sats[i]
            val h = (s.snr / 50f).coerceIn(0.04f, 1f) * chH
            fill(c, x0 + i * bw + 1f, top + chH - h, x0 + (i + 1) * bw - 1f, top + chH, if (s.used) 0xFF3FA34D.toInt() else 0xFF9AA4AE.toInt())
            text(c, sats[i].id.toString(), x0 + i * bw + bw / 2, top + chH + 11f, 7f, 0xFF444444.toInt(), false, Paint.Align.CENTER)
        }
        if (sats.isEmpty()) text(c, "No satellite data", x0 + cw / 2, top + chH / 2, 14f, 0xFF777777.toInt(), false, Paint.Align.CENTER)

        val lines = ArrayList<Pair<String, String>>()
        lines.add("Status" to (if (Gps.hasFix()) "GPS Ready" else "Acquiring Satellites"))
        lines.add("Satellites" to "${Gps.satsUsed} in use / ${Gps.satList.size} visible")
        lines.add("Position" to (if (l != null) Fmt.coord(l.latitude, l.longitude) else "--"))
        lines.add("Accuracy" to (if (l != null && l.hasAccuracy()) Fmt.dist(l.accuracy.toDouble()) else "--"))
        lines.add("Altitude" to (if (l != null && l.hasAltitude()) Fmt.dist(l.altitude) else "--"))
        val sp = if (l != null && l.hasSpeed()) Fmt.speedParts(l.speed) else null
        lines.add("Speed" to (if (sp != null) sp.first + (if (sp.second == "mh") " mph" else " km/h") else "--"))
        var y = top + chH + 38f
        val step = minOf(17f, (H - y - 4f) / lines.size)
        for (ln in lines) {
            text(c, ln.first, 62f, y, 12f, 0xFF666666.toInt())
            text(c, fit(ln.second, 13f, W - 160f, true), 140f, y, 13f, 0xFF1E1E1E.toInt(), true)
            y += step
        }
        sidebar(c)
    }
}
