package com.nuvi.launcher

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class Step(
    val type: String, val mod: String, val name: String, val ref: String,
    val dest: String, val exit: String, val dist: Double, val lat: Double, val lon: Double
) {
    var idx = 0

    val road: String get() = if (name.isNotBlank()) name else ref

    val text: String
        get() {
            val on = if (name.isNotBlank()) " onto $name" else if (ref.isNotBlank()) " onto $ref" else ""
            val dir = when (mod) {
                "left" -> "Turn left"
                "right" -> "Turn right"
                "slight left" -> "Bear left"
                "slight right" -> "Bear right"
                "sharp left" -> "Turn sharp left"
                "sharp right" -> "Turn sharp right"
                "uturn" -> "Make a U-turn"
                else -> "Continue straight"
            }
            return when (type) {
                "depart" -> if (name.isNotBlank()) "Head out on $name" else "Start driving"
                "arrive" -> "Arrive at your destination"
                "roundabout", "rotary", "roundabout turn" -> "Take the roundabout exit$on"
                "continue", "new name" -> if (mod == "straight" || mod == "") "Continue$on" else dir + on
                "merge" -> "Merge$on"
                "fork" -> (if (mod.contains("left")) "Keep left" else if (mod.contains("right")) "Keep right" else "Continue") + on
                "off ramp" -> "Take the exit$on"
                "on ramp" -> "Take the ramp$on"
                else -> dir + on
            }
        }

    val angle: Float
        get() = when (mod) {
            "slight right" -> 35f
            "right" -> 90f
            "sharp right" -> 140f
            "sharp left" -> -140f
            "left" -> -90f
            "slight left" -> -35f
            else -> 0f
        }
}

class Route(
    val lat: DoubleArray, val lon: DoubleArray, val cum: DoubleArray,
    val steps: List<Step>, val dist: Double, val dur: Double, val note: String?
)

object Net {
    private val ex = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun <T> async(work: () -> T, done: (Result<T>) -> Unit) {
        ex.execute {
            val r = runCatching(work)
            main.post { done(r) }
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun http(url: String, post: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 40000
        c.setRequestProperty("User-Agent", "NuviLauncher/1.0 (Android launcher app)")
        if (post != null) {
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.outputStream.use { it.write(post.toByteArray()) }
        }
        val code = c.responseCode
        if (code !in 200..299) throw IOException("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    // ---------- Nominatim geocoding ----------
    fun geocode(q: String?, params: Map<String, String>, near: Pair<Double, Double>?): List<Place> {
        val sb = StringBuilder("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=15")
        if (q != null) sb.append("&q=").append(enc(q))
        for ((k, v) in params) sb.append("&").append(k).append("=").append(enc(v))
        if (near != null && q != null) {
            val d = 0.5
            sb.append("&viewbox=${near.second - d},${near.first + d},${near.second + d},${near.first - d}")
        }
        val a = JSONArray(http(sb.toString()))
        val out = ArrayList<Place>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val dn = o.optString("display_name")
            val nm = o.optString("name").ifBlank { dn.substringBefore(",") }
            out.add(Place(nm, dn, o.getDouble("lat"), o.getDouble("lon")))
        }
        return out
    }

    // ---------- Overpass ----------
    private fun overpass(q: String): JSONArray =
        JSONObject(http("https://overpass-api.de/api/interpreter", "data=" + enc(q))).getJSONArray("elements")

    fun pois(cat: Cats.Cat, lat: Double, lon: Double): List<Place> {
        var out = listOf<Place>()
        for (r in intArrayOf(3000, 10000, 25000)) {
            val q = "[out:json][timeout:25];(node${cat.filter}(around:$r,$lat,$lon);way${cat.filter}(around:$r,$lat,$lon););out center 80;"
            val els = overpass(q)
            val l = ArrayList<Place>()
            for (i in 0 until els.length()) {
                val e = els.getJSONObject(i)
                val t = e.optJSONObject("tags") ?: JSONObject()
                val la: Double
                val lo: Double
                if (e.has("lat")) { la = e.getDouble("lat"); lo = e.getDouble("lon") }
                else { val c = e.optJSONObject("center") ?: continue; la = c.getDouble("lat"); lo = c.getDouble("lon") }
                val name = t.optString("name").ifBlank { t.optString("brand").ifBlank { t.optString("operator").ifBlank { cat.name } } }
                val addr = listOf(t.optString("addr:street"), t.optString("addr:housenumber"), t.optString("addr:city"))
                    .filter { it.isNotBlank() }.joinToString(" ")
                l.add(Place(name, addr, la, lo))
            }
            out = l
            if (out.size >= 5) break
        }
        return out.sortedBy { hav(lat, lon, it.lat, it.lon) }.take(40)
    }

    private fun clean(s: String) = s.filter { it.isLetterOrDigit() || it == ' ' || it == '-' || it == '\'' }

    fun intersections(a: String, b: String, lat: Double, lon: Double): List<Place> {
        val ea = clean(a)
        val eb = clean(b)
        val q = "[out:json][timeout:25];" +
            "way[\"highway\"][\"name\"~\"^${ea}\$\",i](around:30000,$lat,$lon)->.a;" +
            "way[\"highway\"][\"name\"~\"^${eb}\$\",i](around:30000,$lat,$lon)->.b;" +
            "node(w.a)->.na;node(w.b)->.nb;node.na.nb;out 20;"
        val els = overpass(q)
        val out = ArrayList<Place>()
        for (i in 0 until els.length()) {
            val e = els.getJSONObject(i)
            out.add(Place("${a.trim()} & ${b.trim()}", Fmt.coord(e.getDouble("lat"), e.getDouble("lon")), e.getDouble("lat"), e.getDouble("lon")))
        }
        return out.sortedBy { hav(lat, lon, it.lat, it.lon) }
    }

    /** Current road name and speed limit (km/h, 0 = unknown) from OSM tags near the position. */
    fun roadInfo(lat: Double, lon: Double): Pair<String, Int> {
        val els = overpass("[out:json][timeout:10];way(around:15,$lat,$lon)[\"highway\"];out tags 8;")
        for (i in 0 until els.length()) {
            val t = els.getJSONObject(i).optJSONObject("tags") ?: continue
            val nm = t.optString("name").ifBlank { t.optString("ref") }
            if (nm.isBlank()) continue
            val ms = t.optString("maxspeed")
            val n = ms.filter { it.isDigit() }.toIntOrNull() ?: 0
            val kmh = if (ms.contains("mph")) (n * 1.609).roundToInt() else n
            return Pair(nm, kmh)
        }
        return Pair("", 0)
    }

    // ---------- OSRM routing ----------
    fun route(flat: Double, flon: Double, tlat: Double, tlon: Double, avoidHw: Boolean, avoidToll: Boolean): Route {
        val base = "https://router.project-osrm.org/route/v1/driving/$flon,$flat;$tlon,$tlat?overview=full&geometries=geojson&steps=true"
        val ex = ArrayList<String>()
        if (avoidHw) ex.add("motorway")
        if (avoidToll) ex.add("toll")
        if (ex.isEmpty()) return parseRoute(http(base), null)
        return try {
            parseRoute(http(base + "&exclude=" + ex.joinToString(",")), null)
        } catch (e: IOException) {
            parseRoute(http(base), "Route options not supported by routing server; using default route")
        }
    }

    private fun parseRoute(s: String, note: String?): Route {
        val j = JSONObject(s)
        if (j.optString("code") != "Ok") throw IOException(j.optString("message", j.optString("code")))
        val r = j.getJSONArray("routes").getJSONObject(0)
        val co = r.getJSONObject("geometry").getJSONArray("coordinates")
        val n = co.length()
        val la = DoubleArray(n)
        val lo = DoubleArray(n)
        val cum = DoubleArray(n)
        for (i in 0 until n) {
            val pt = co.getJSONArray(i)
            lo[i] = pt.getDouble(0)
            la[i] = pt.getDouble(1)
            if (i > 0) cum[i] = cum[i - 1] + hav(la[i - 1], lo[i - 1], la[i], lo[i])
        }
        val steps = ArrayList<Step>()
        val legs = r.getJSONArray("legs")
        for (k in 0 until legs.length()) {
            val st = legs.getJSONObject(k).getJSONArray("steps")
            for (i in 0 until st.length()) {
                val o = st.getJSONObject(i)
                val m = o.getJSONObject("maneuver")
                val loc = m.getJSONArray("location")
                steps.add(Step(m.optString("type"), m.optString("modifier"), o.optString("name"), o.optString("ref"),
                    o.optString("destinations"), o.optString("exits"), o.optDouble("distance"), loc.getDouble(1), loc.getDouble(0)))
            }
        }
        var from = 0
        for (st in steps) {
            var best = from
            var bd = Double.MAX_VALUE
            for (i in from until n) {
                val d = hav(st.lat, st.lon, la[i], lo[i])
                if (d < bd) { bd = d; best = i }
            }
            st.idx = best
            from = best
        }
        if (steps.isNotEmpty()) steps.last().idx = n - 1
        return Route(la, lo, cum, steps, r.getDouble("distance"), r.getDouble("duration"), note)
    }
}
