package com.nuvi.launcher

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import org.osmdroid.config.Configuration
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private val stack = ArrayList<View>()
    private var mapScreen: MapScreen? = null
    private var busyOn = false
    private var asked = false
    var nearHome = false

    private val busyView by lazy {
        TextView(this).apply {
            setBackgroundColor(0xE6202020.toInt())
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            val pd = (DENSITY * 24).toInt()
            setPadding(pd * 2, pd, pd * 2, pd)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DENSITY = resources.displayMetrics.density
        Prefs.init(this)
        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osm", MODE_PRIVATE))
            userAgentValue = packageName
            osmdroidBasePath = File(cacheDir, "osm")
            osmdroidTileCache = File(cacheDir, "osm/tiles")
        }
        Voice.init(this)
        Gps.init(this)
        Gps.listeners.add { Nav.onLoc(it) }
        Nav.msg = { toast(it) }
        Nav.speaker = { Voice.say(it) }

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        setContentView(root)
        applyPrefs()
        push(HomePane(this))
    }

    override fun onStart() {
        super.onStart()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) Gps.start()
        else if (!asked) {
            asked = true
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        }
    }

    override fun onStop() {
        super.onStop()
        Gps.stop()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) Gps.start()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) goHome()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersive()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (stack.size > 1) pop()   // as a launcher, Back on the home screen does nothing
    }

    // ------------------------------------------------------------ system settings
    fun applyPrefs() {
        requestedOrientation = when (Prefs.orientation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        val lp = window.attributes
        lp.screenBrightness = if (Prefs.brightness <= 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else Prefs.brightness / 100f
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
        applyImmersive()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersive() {
        root.fitsSystemWindows = !Prefs.immersive
        root.requestApplyInsets()
        window.decorView.systemUiVisibility = if (Prefs.immersive) (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            ) else View.SYSTEM_UI_FLAG_VISIBLE
    }

    fun keepOn(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ------------------------------------------------------------ screen stack
    private fun show(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        if (busyOn) root.addView(busyView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        (v as? Screen)?.onShow()
    }

    fun push(v: View) {
        (stack.lastOrNull() as? Screen)?.onHide()
        stack.add(v)
        show(v)
    }

    fun pop() {
        if (stack.size <= 1) return
        (stack.removeAt(stack.size - 1) as? Screen)?.onHide()
        show(stack.last())
    }

    fun goHome() {
        if (stack.size <= 1) return
        while (stack.size > 1) (stack.removeAt(stack.size - 1) as? Screen)?.onHide()
        show(stack[0])
    }

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun busy(m: String?) {
        root.removeView(busyView)
        busyOn = m != null
        if (m != null) {
            busyView.text = m
            root.addView(busyView, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }
    }

    // ------------------------------------------------------------ navigation helpers
    private fun mapScreen(): MapScreen = mapScreen ?: MapScreen(this).also { mapScreen = it }

    fun openMap() { goHome(); push(mapScreen()) }

    fun showOnMap(p: Place) { goHome(); val m = mapScreen(); push(m); m.showPin(p) }

    fun startNav(p: Place) {
        Prefs.addRecent(p)
        Nav.start(p)
        goHome()
        val m = mapScreen()
        push(m)
        m.recenter()
    }

    fun showPlace(p: Place) {
        Prefs.addRecent(p)
        push(DetailPane(this, p))
    }

    fun near(): Pair<Double, Double>? {
        val h = Prefs.home
        if (nearHome && h != null) return Pair(h.lat, h.lon)
        val l = Gps.loc ?: return null
        return Pair(l.latitude, l.longitude)
    }

    fun nearLabel(): String = if (nearHome && Prefs.home != null) "Home" else "My Current Location"

    fun toggleNear() {
        if (Prefs.home == null) { toast("Set a home location first"); nearHome = false } else nearHome = !nearHome
    }

    // ------------------------------------------------------------ Where To? flows
    fun openWhere() = push(WherePane(this))

    fun runSearch(title: String, pick: ((Place) -> Unit)?, work: () -> List<Place>) {
        busy("Searching…")
        Net.async(work) { r ->
            busy(null)
            r.onSuccess { showResults(title, it, pick) }
            r.onFailure { toast("Search failed: " + (it.message ?: "network error")) }
        }
    }

    fun showResults(title: String, list: List<Place>, pick: ((Place) -> Unit)? = null) {
        if (list.isEmpty()) { toast("No results found"); return }
        val here = Gps.loc
        val rows = list.map { pl ->
            Row(pl.name, pl.addr, here?.let { Fmt.dist(hav(it.latitude, it.longitude, pl.lat, pl.lon)) },
                tap = { if (pick != null) pick(pl) else showPlace(pl) })
        }
        push(ListPane(this, title) { rows })
    }

    fun openSearch() = push(KeyPane(this, "Type a place name or address", "", true) { q ->
        val n = near()
        runSearch("Search Results", null) { Net.geocode(q, emptyMap(), n) }
    })

    fun searchCategory(cat: Cats.Cat) {
        val n = near()
        if (n == null) { toast("Waiting for GPS position"); return }
        runSearch(cat.name, null) { Net.pois(cat, n.first, n.second) }
    }

    fun openCategories() = push(ListPane(this, "Categories") {
        Cats.all.map { cat -> Row(cat.name, icon = cat.icon, tap = { searchCategory(cat) }) }
    })

    fun openSaved() = push(ListPane(this, "Saved") {
        val l = Prefs.places("saved")
        if (l.isEmpty()) listOf(Row("No saved places yet", sub = "Open a place and tap Save"))
        else l.map { pl -> Row(pl.name, pl.addr, icon = "heart", tap = { showPlace(pl) }) }
    })

    fun openRecents() = push(ListPane(this, "Recently Found") {
        val l = Prefs.places("recent")
        if (l.isEmpty()) listOf(Row("Nothing found recently"))
        else l.map { pl -> Row(pl.name, pl.addr, icon = "clock", tap = { showPlace(pl) }) }
    })

    fun goHomePlace() {
        val h = Prefs.home
        if (h != null) startNav(h) else setHomeFlow()
    }

    fun setHomeFlow() = push(ListPane(this, "Set Home Location") {
        listOf(
            Row("Enter My Address", icon = "address", tap = {
                openAddress { pl -> Prefs.home = pl; toast("Home location set"); goHome() }
            }),
            Row("Use My Current Location", icon = "mapPin", tap = {
                val l = Gps.loc
                if (l == null) toast("Waiting for GPS position")
                else { Prefs.home = Place("Home", Fmt.coord(l.latitude, l.longitude), l.latitude, l.longitude); toast("Home location set"); goHome() }
            })
        )
    })

    private class Addr(var country: String, var city: String = "", var street: String = "", var number: String = "")

    fun openAddress(pick: ((Place) -> Unit)?) {
        val st = Addr(Locale.getDefault().displayCountry)
        fun field(label: String, value: String, set: (String) -> Unit) =
            Row(label, value = value.ifBlank { "Not set" }, tap = { push(KeyPane(this, label, value) { v -> set(v.trim()); pop() }) })
        push(ListPane(this, "Address") {
            listOf(
                field("Country", st.country) { st.country = it },
                field("City", st.city) { st.city = it },
                field("Street", st.street) { st.street = it },
                field("House Number", st.number) { st.number = it },
                Row("Search", icon = "search", tap = {
                    val params = LinkedHashMap<String, String>()
                    if (st.street.isNotBlank()) params["street"] = (st.number + " " + st.street).trim()
                    if (st.city.isNotBlank()) params["city"] = st.city
                    if (st.country.isNotBlank()) params["country"] = st.country
                    if (!params.containsKey("street") && !params.containsKey("city")) toast("Enter a city or a street")
                    else runSearch("Address", pick) { Net.geocode(null, params, null) }
                })
            )
        })
    }

    fun openCities() = push(KeyPane(this, "Type a city name", "", true) { q ->
        runSearch("Cities", null) { Net.geocode(q, mapOf("featureType" to "city"), null) }
    })

    fun openCoords() = push(KeyPane(this, "Enter latitude, longitude  e.g. 31.95, 35.93", "") { q ->
        val parts = q.replace(";", ",").split(",", " ").filter { it.isNotBlank() }
        val la = parts.getOrNull(0)?.toDoubleOrNull()
        val lo = parts.getOrNull(1)?.toDoubleOrNull()
        if (parts.size != 2 || la == null || lo == null || la !in -90.0..90.0 || lo !in -180.0..180.0) toast("Use the form: latitude, longitude")
        else showPlace(Place("Coordinates", Fmt.coord(la, lo), la, lo))
    })

    fun openIntersections() = push(KeyPane(this, "Enter two streets, e.g. Main St & 5th Ave", "") { q ->
        val parts = q.split("&", " and ").map { it.trim() }.filter { it.isNotEmpty() }
        val n = near()
        if (parts.size != 2) toast("Enter two streets separated by &")
        else if (n == null) toast("Waiting for GPS position")
        else runSearch("Intersections", null) { Net.intersections(parts[0], parts[1], n.first, n.second) }
    })

    // ------------------------------------------------------------ home-screen items
    fun openApps() {
        val pm = packageManager
        val ri = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val rows = ri.map { r ->
            Row(r.loadLabel(pm).toString(), img = r.loadIcon(pm), tap = {
                pm.getLaunchIntentForPackage(r.activityInfo.packageName)?.let { startActivity(it) }
            })
        }
        push(ListPane(this, "Apps") { rows })
    }

    fun openVolume() {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        val max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
        push(LevelPane(this, "Volume",
            { am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) * 100 / maxOf(1, max) },
            { v -> am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (v * max / 100.0).roundToInt(), 0) },
            "Mute", { am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, 0, 0) }))
    }

    fun openBrightness() = push(LevelPane(this, "Brightness",
        { if (Prefs.brightness <= 0) 50 else Prefs.brightness },
        { v -> Prefs.brightness = maxOf(5, v); applyPrefs() },
        "System Default", { Prefs.brightness = 0; applyPrefs() }))

    fun openSettings() = push(settingsRoot(this))

    fun openMapMenu() = push(ListPane(this, "Menu") {
        val l = ArrayList<Row>()
        if (Nav.dest != null) {
            l.add(Row("Stop Route", icon = "stop", tap = { Nav.stop(); pop() }))
            if (Nav.route != null) l.add(Row("Turn List", icon = "menu", tap = { openTurnList() }))
        }
        l.add(Row("Map Colors", value = listOf("Auto", "Day", "Night")[Prefs.colorMode], tap = { Prefs.colorMode = (Prefs.colorMode + 1) % 3 }))
        l.add(Row("Settings", icon = "tools", tap = { openSettings() }))
        l
    })

    fun openTurnList() {
        val r = Nav.route ?: return
        push(ListPane(this, "Turns") {
            r.steps.map { s -> Row(s.text, value = if (s.type == "arrive") null else Fmt.dist(s.dist)) }
        })
    }
}
