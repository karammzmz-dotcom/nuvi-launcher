# nüvi Launcher

An Android home launcher that recreates the Garmin nüvi 55 interface: Where To? / View Map home screen,
Stop / Apps / Volume / Settings row, Where To? grid, on-screen keyboard, address search, categories,
saved / recent places, nav map with turn panel, speed, limit, arrival, and Garmin-style settings.

## Build the APK with GitHub Actions
1. Create a new GitHub repository and push **everything in this folder** (including the hidden `.github` folder).
2. Open the **Actions** tab -> the *Build APK* run (workflow `.github/workflows/unzip.yml`).
3. When it finishes, download the **nuvi-launcher-apk** artifact (contains `app-debug.apk`).

The workflow sets up JDK 17, the Android SDK and Gradle 8.5, runs `gradle wrapper` to create `gradlew` and
`gradle-wrapper.jar` (the binary jar could not be pre-bundled), makes `gradlew` executable and runs `./gradlew assembleDebug`.
`gradle/wrapper/gradle-wrapper.properties` is included.

## Install and set as home
Install the APK, press Home and choose **nüvi Launcher** -> Always. Or Settings -> About -> *Set as Default Home App*.
Allow the location permission when asked.

## Services used (all free, no API keys)
* Map tiles: OpenStreetMap via osmdroid (tinted, not the Garmin vector map; night mode inverts the tiles).
* Routing: public OSRM demo server (avoid highways / tolls are sent as `exclude`; if the server refuses, the default route is used).
* Search: Nominatim (addresses, cities, free text). Categories, intersections, current road and speed limit: Overpass API.
These public servers are rate limited and need internet.

## Notes and limits
* Navigation runs while the app is in the foreground; it stops GPS when you open another app.
* Speed limit / road name come from OSM tags and may be missing.
* Long-press on the map drops a pin. Tap the Arrival panel to cycle arrival / remaining / time left.
* The UI text is English; Language settings change keyboard layout (English/Arabic) and voice accent.
